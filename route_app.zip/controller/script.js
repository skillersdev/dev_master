	// create the module and name it scotchApp
	var bookingApp = angular.module('bookingApp', ['ngRoute']);

	// configure our routes
	bookingApp.config(function($routeProvider) {
		$routeProvider

			// route for the home page
			.when('/', {
				templateUrl : 'app/home.html',
				controller  : 'mainController'
			})

			// route for the about page
			.when('/about', {
				templateUrl : 'app/about.html',
				controller  : 'aboutController'
			})

			// route for the contact page
			.when('/contact', {
				templateUrl : 'app/contact.html',
				controller  : 'contactController'
			});
	});

	// create the controller and inject Angular's $scope
	bookingApp.controller('mainController', function($scope) {
		// create a message to display in our view
		$scope.message = 'Everyone come and see how good I look!';
	});

	bookingApp.controller('aboutController', function($scope) {
		$scope.message = 'Look! I am an about page.';
	});

	bookingApp.controller('contactController', function($scope) {
		$scope.message = 'Contact us! JK. This is just a demo.';
	});