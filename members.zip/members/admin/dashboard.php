<?php
include_once ("z_db.php");
// Inialize session
session_start();
// Check, if username session is NOT set then this page will jump to login page
if (!isset($_SESSION['adminidusername'])) {
        print "
				<script language='javascript'>
					window.location = 'index.php';
				</script>
				
			";
}

?>
<!DOCTYPE html>
<html lang="en" class="app">
<head>
<meta charset="utf-8" />
<title>Roodabatoz Admin Panel</title>
<meta name="description" content="app, web app, responsive, admin dashboard, admin, flat, flat ui, ui kit, off screen nav" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<link rel="stylesheet" href="css/app.v1.css" type="text/css" />
<link rel="stylesheet" href="js/calendar/bootstrap_calendar.css" type="text/css" />
<!--[if lt IE 9]> <script src="js/ie/html5shiv.js"></script> <script src="js/ie/respond.min.js"></script> <script src="js/ie/excanvas.js"></script> <![endif]-->


<script  type="text/javascript" src="dist/js/jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="dist/js/select2.js"></script>
<link href="dist/css/select2.min.css" type="text/css" rel="stylesheet" />

<script type="text/javascript">
$(document).ready(function() {
  $(".js-example-basic-single").select2();
});
</script>




</head>
<body class="">
<section class="vbox">
  <header class="bg-white header header-md navbar navbar-fixed-top-xs box-shadow">
    <div class="navbar-header aside-md dk"> <a class="btn btn-link visible-xs" data-toggle="class:nav-off-screen" data-target="#nav"> <i class="fa fa-bars"></i> </a> <a href="dashboard.php" class="navbar-brand"><img src="images/logo.png" class="m-r-sm">Roodabatoz</a> <a class="btn btn-link visible-xs" data-toggle="dropdown" data-target=".user"> <i class="fa fa-cog"></i> </a> </div>
  
    
    <ul class="nav navbar-nav navbar-right m-n hidden-xs nav-user user">
      
      <li class="dropdown"> 
	  <a href="#" class="dropdown-toggle" data-toggle="dropdown"> 
	  <span class="thumb-sm avatar pull-left"> 
	  <img src="images/a0.jpg"> 
	  </span> <?php
		  $sql="SELECT fname FROM  affiliateuser WHERE username='".$_SESSION['adminidusername']."'";
		  if ($result = mysqli_query($con, $sql)) {

    /* fetch associative array */
    while ($row = mysqli_fetch_row($result)) {
        print $row[0];
    }

}

   
	   
	   ?><b class="caret"></b> </a>
        <ul class="dropdown-menu animated fadeInRight">
          <span class="arrow top"></span>
          <li> <a href="profile.php">Profile</a> </li>
          <li class="divider"></li>
          <li> <a href="logout.php" data-toggle="ajaxModal" >Logout</a> </li>
        </ul>
      </li>
    </ul>
  </header>
  <section>
    <section class="hbox stretch">
      <!-- .aside -->
      <aside class="bg-black aside-md hidden-print" id="nav">
        <section class="vbox">
          <section class="w-f scrollable">
            <div class="slim-scroll" data-height="auto" data-disable-fade-out="true" data-distance="0" data-size="10px" data-color="#333333">
              <div class="clearfix wrapper dk nav-user hidden-xs">
                <div class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <span class="thumb avatar pull-left m-r"> <img src="images/a0.jpg"> <i class="on md b-black"></i> </span> <span class="hidden-nav-xs clear"> <span class="block m-t-xs"> <strong class="font-bold text-lt"><?php
		  $sql="SELECT fname,country FROM  affiliateuser WHERE username='".$_SESSION['adminidusername']."'";
		  if ($result = mysqli_query($con, $sql)) {

    /* fetch associative array */
    while ($row = mysqli_fetch_row($result)) {
        print $row[0];
		$coun=$row[1];
    }

}

   
	   
	   ?></strong> <b class="caret"></b> </span> </span> </a>
                  <ul class="dropdown-menu animated fadeInRight m-t-xs">
                    <span class="arrow top hidden-nav-xs"></span>
                    <li> <a href="profile.php">Profile</a> </li>
                    <li class="divider"></li>
                    <li> <a href="logout.php" data-toggle="ajaxModal" >Logout</a> </li>
                  </ul>
                </div>
              </div>
             <?php require("nav.php"); ?>
            </div>
          </section>
          <footer class="footer hidden-xs no-padder text-center-nav-xs"> <a href="logout.php" data-toggle="ajaxModal" class="btn btn-icon icon-muted btn-inactive pull-right m-l-xs m-r-xs hidden-nav-xs"> <i class="i i-logout"></i> </a> <a href="#nav" data-toggle="class:nav-xs" class="btn btn-icon icon-muted btn-inactive m-l-xs m-r-xs"> <i class="i i-circleleft text"></i> <i class="i i-circleright text-active"></i> </a> </footer>
        </section>
      </aside>
      <!-- /.aside -->
      <section id="content">
        <section class="hbox stretch">
          <section>
            <section class="vbox">
              <section class="scrollable padder">
                <section class="row m-b-md">
                  <div class="col-sm-6">
                    <h3 class="m-b-xs text-black">Dashboard</h3>
                    <small>Welcome back, <?php
		  $sql="SELECT fname FROM  affiliateuser WHERE username='".$_SESSION['adminidusername']."'";
		  if ($result = mysqli_query($con, $sql)) {

    /* fetch associative array */
    while ($row = mysqli_fetch_row($result)) {
        print $row[0];
    }

}

   
	   
	   ?>, <i class="fa fa-map-marker fa-lg text-primary"></i> <?php print $coun ?></small> </div>
                  <div class="col-sm-6 text-right text-left-xs m-t-md">
                    
                     <a href="#nav, #sidebar" class="btn btn-icon b-2x btn-info btn-rounded" data-toggle="class:nav-xs, show"><i class="fa fa-bars"></i></a> </div>
                </section>
                <div class="row">
				<div class="col-lg-12">
                <section class="panel panel-default">
                  <div class="panel-body">
                    <?php $query="SELECT id,fname,email,doj,active,username,address,pcktaken,tamount FROM  affiliateuser where username = '".$_SESSION['adminidusername']."'"; 
 
 
 $result = mysqli_query($con,$query);

while($row = mysqli_fetch_array($result))
{
 $aid="$row[id]";
 $regdate="$row[doj]";
 $name="$row[fname]";
 $address="$row[address]";
 $acti="$row[active]";
 $pck="$row[pcktaken]";
 $ear="$row[tamount]";
 
 }
 ?> 
 <?php
$result = mysqli_query($con,"SELECT count(*) FROM  affiliateuser where active = 1");
$row = mysqli_fetch_row($result);
$totalusers = $row[0];
?>
                  <footer class="panel-footer bg-info text-center">
                    <div class="row pull-out">
                      <div class="col-xs-6">
                        <div class="padder-v"> <span class="m-b-xs h3 block text-white"><?php print $totalusers ?></span> <small class="text-muted">Total Users</small> </div>
                      </div>
                      <div class="col-xs-6 dk">
					  <?php $query="SELECT orderid,price FROM  paypalpayments"; 
 
 
 $result = mysqli_query($con,$query);
 
$totalpayments=0;
while($row = mysqli_fetch_array($result))
{
$oid="$row[orderid]";
$result2 = mysqli_query($con,"SELECT count(*) FROM  affiliateuser where Id='$oid'  and active = 1");
$row22 = mysqli_fetch_row($result2);
$toid = $row22[0];
if($toid==1){

 $totalpayments = $totalpayments + $ppayment="$row[price]";
 if($_SESSION['adminidusername']!="roodabatoz"){
 $up_queryss=mysqli_query($con,"update affiliateuser set tamount='".$totalpayments ."' where username='".$_SESSION['adminidusername']."'");//code added
 }
 }
  }
  
$query9=mysqli_query($con,"SELECT  SUM(amt) As TotalAmtT FROM transfer_history WHERE transfer_from= '".$_SESSION['adminidusername']."'");
$row9=$query9->fetch_array(MYSQLI_ASSOC);
$tot_amt_trans=$row9['TotalAmtT'];

$query55=mysqli_query($con,"SELECT  tamount As TotalAmt1 FROM affiliateuser WHERE username = '".$_SESSION['adminidusername']."'");
$row55=$query55->fetch_array(MYSQLI_ASSOC);
$tot_bal_avail5=($row55['TotalAmt1']); 
 if($_SESSION['adminidusername']!="roodabatoz"){
//$totalpayments5=$tot_bal_avail5-$tot_amt_trans;
$totalpayments5=$tot_bal_avail5;
}
else{
$totalpayments5=$tot_bal_avail5;
}
$up_queryss2=mysqli_query($con,"update affiliateuser set tamount='".$totalpayments5 ."' where username='".$_SESSION['adminidusername']."'");//code added




 ?>
                        <div class="padder-v"> <span class="m-b-xs h3 block text-white"><?php print $totalpayments5 ?></span> <small class="text-muted">Total Payments Till Now </small> </div>
                      </div>
                      
                    </div>
                    
                    
                    
          <!-- code for showing the upgradation earning--> 
                    <div class="row pull-out">
                      <?php
			
$result1 = mysqli_query($con,"SELECT sum(tamount) FROM  affiliateuser WHERE username= '".$_SESSION['adminidusername']."'");
$row1 = mysqli_fetch_row($result1);
//$tot1=$row1[0];			
$tot1="";
$result = mysqli_query($con,"SELECT sum(upgrade_cost) AS up_tot FROM  affliate_stage_bonus");
$row = mysqli_fetch_row($result);
$tot = $row[0] + $tot1;



if($tot !=0){

?>
					  <div class="col-xs-6 dk">
					    <div class="padder-v"> 
							<span class="m-b-xs h3 block text-white">
								<?php @print $pcur ?><?php print $tot ?>
							</span> 
							<small class="text-muted">Up-gradation/Earnings</small> 
						</div>
                      </div>
<?php } ?>					  
					  
					  
                      
                    </div>
                  
					
					 <!-- code ends here for showing the upgradation earning-->           
                    
                    
                    
                    
                    
                    
                    
                  </footer>
                </section>
              </div>
                  
                  
                  
                         <!-- balance transfer code starts here-->
		    <div class="col-lg-12">
                <section class="panel panel-default">
                  <div class="panel-body">
					 <h4>Share Balance to Marketer</h4><h5>(to share the balance. you should have more than 50RM balance)</h5>
					 <form action="dashboard.php" method="post">
						 <div class="form-group">
							<?php $query_marketer="SELECT username,tamount FROM  affiliateuser";
								   $result_marketer= mysqli_query($con,$query_marketer);
							?>
	 						<select class="col-xs-4 js-example-basic-single" name="marketer" id="marketer-sel" required >
							
								<option value="">--select marketer--</option>
								<?php while($row = mysqli_fetch_array($result_marketer))
																  {
																   $marketer_name="$row[username]";
																   
															 ?>     
										<option vallue="<?php echo $marketer_name; ?>"><?php echo $marketer_name; ?></option>
								<?php } ?>
							</select>
						 </div>
						 <br/> <br/>
						 
						 <div class="form-group">
							<input type="text" name="amt" id="amt" placeholder="Enter Amount to share" class="col-xs-4" required />
							
						 </div>
						 <br/>
						 <div class="form-group">
							<button type="submit" class="btn btn-primary col-xs-4" name="transfer" id="transfer">Transfer</button>
						 </div>
					 </form>
				  </div>
				  
				  <?php
				  if(isset($_POST['transfer'])){
				  
				  	$amount=$_POST['amt'];
				  	$transfer_to=$_POST['marketer'];
				  	$transfer_form=$_SESSION['adminidusername'];
				  	
				  	
				  	$query5=mysqli_query($con,"SELECT  tamount As TotalAmt1 FROM affiliateuser WHERE username = '$transfer_form'");
					$row5=$query5->fetch_array(MYSQLI_ASSOC);
					$tot_bal_avail=($row5['TotalAmt1']); 
				  	
				  					  	
				  	if($tot_bal_avail >50){
					  	
					  	$tot_amt=$tot_bal_avail-$amount;
					  	$up_query1=mysqli_query($con,"update affiliateuser set tamount='".$tot_amt."' where username='".$transfer_form."'");
					  	$query_trans=mysqli_query($con,"insert into transfer_history values ('','$transfer_form','$transfer_to','$amount')");
					  	$query4=mysqli_query($con,"SELECT  tamount As TotalAmt FROM affiliateuser WHERE username = '$transfer_to'");
						$row4=$query4->fetch_array(MYSQLI_ASSOC);
						$tot_amt2=($row4['TotalAmt']+$amount); 
					  	$up_query2=mysqli_query($con,"update affiliateuser set tamount='".$tot_amt2."' where username='".$transfer_to."'");
					  	
					  	print "
				<script language='javascript'>
				        alert('Balance shared to marketer successfully!');
				        window.location = 'dashboard.php';
					
				</script>
			"; 		
					  }
					  else
					  { 
					  	print "
				<script language='javascript'>
				        alert('Insufficient Balance to Transfer!');
				       
					
				</script>
			"; 		
					//window.location = 'dashboard.php';  
					   }	
				  }
				  ?>
				  
				  
				 </section>
			</div>
<!-- code ends here -->




                  <div class="col-md-6 col-sm-6">
                    <div class="panel b-a">
						  <?php $query="SELECT * FROM  settings"; 
 
 
 $result = mysqli_query($con,$query);

while($row = mysqli_fetch_array($result))
{
 $fblink="$row[fblink]";
 $twilink="$row[twitterlink]";
 
 }
 ?>
                      <div class="panel-heading no-border bg-primary lt text-center"> <a href="<?php print $fblink ?>"> <i class="fa fa-facebook fa fa-3x m-t m-b text-white"></i> </a> </div>
                      <div class="padder-v text-center clearfix">
                        <div class="col-xs-6 b-r">
						<div class="h3 font-bold">Like</div>
                          <small class="text-muted">us on facebook</small> 
                          </div>
                        <div class="col-xs-6">
						<div class="h3 font-bold">Right</div>
                          <small class="text-muted">now</small>
                          </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6 col-sm-6">
                    <div class="panel b-a">
                      <div class="panel-heading no-border bg-info lter text-center"> <a href="<?php print $twilink ?>"> <i class="fa fa-twitter fa fa-3x m-t m-b text-white"></i> </a> </div>
                      <div class="padder-v text-center clearfix">
                        <div class="col-xs-6 b-r">
                          <div class="h3 font-bold">Follow</div>
                          <small class="text-muted">us on twitter</small> </div>
                        <div class="col-xs-6">
                          <div class="h3 font-bold">Right</div>
                          <small class="text-muted">now</small> </div>
                      </div>
                    </div>
                  </div>
                  </div>
                  
                </div>
                
                
              
            </section>
          </section>
    
          <!-- / side content -->
        </section>
        <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a> </section>
    </section>
  </section>
</section>
<!-- Bootstrap -->
<!-- App -->
<!-- <script src="js/app.v1.js"></script>
<script src="js/charts/easypiechart/jquery.easy-pie-chart.js"></script>
<script src="js/charts/sparkline/jquery.sparkline.min.js"></script>
<script src="js/charts/flot/jquery.flot.min.js"></script>
<script src="js/charts/flot/jquery.flot.tooltip.min.js"></script>
<script src="js/charts/flot/jquery.flot.spline.js"></script>
<script src="js/charts/flot/jquery.flot.pie.min.js"></script>
<script src="js/charts/flot/jquery.flot.resize.js"></script>
<script src="js/charts/flot/jquery.flot.grow.js"></script>
<script src="js/charts/flot/demo.js"></script>
<script src="js/calendar/bootstrap_calendar.js"></script>
<script src="js/calendar/demo.js"></script>
<script src="js/sortable/jquery.sortable.js"></script>
-->

<script src="js/app.plugin.js">
</script>


<script src="js/app.v1.js"></script></body>
</html>