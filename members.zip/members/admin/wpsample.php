<?php
include_once ("z_db.php");

$tomake= $_GET["username"];

$ref_query11=mysqli_query($con,"SELECT  * FROM affiliateuser WHERE username='$tomake'");
$ref_list11=$ref_query11->fetch_array(MYSQLI_ASSOC);
$ref=$ref_list11['referedby'];
require_once('../../products/wp-load.php');


    $user_name = $ref_list11['username'];
    $user_email = $ref_list11['email'];
    $user_id = username_exists( $user_name );
    if ( !$user_id ) {
       $password = $ref_list11['password'];
       $user_id = wp_create_user( $user_name,$password,$user_email );
		wp_set_password( $password, $user_id );
		$user_id_role = new WP_User($user_id);
		$user_id_role->set_role('seller');
		$updated1 = update_user_meta( $user_id, 'dokan_enable_selling', 'yes' );
		$updated2 = update_user_meta( $user_id, 'dokan_publishing', 'no' );
	} 
	else
	{
		
		$password = $ref_list11['password'];
		wp_set_password( $password, $user_id );
		$user_id_role = new WP_User($user_id);
		$user_id_role->set_role('seller');
	}
	
echo "<pre>";
print_r($ref_list11['username']);
exit;


	
	$user_name = $ref_list11['username'];
    $user_email = $ref_list11['email'];
    $user_id = username_exists( $user_name );
    if ( !$user_id ) {
        $password = $ref_list11['password'];
        $user_id = wp_create_user( $user_name,$user_email );
		wp_set_password( $password, $user_id );
	} 


?>