<?php
header( "refresh:2;url=paymentscod.php" );
include_once ("z_db.php");
// Inialize session
session_start();
// Check, if username session is NOT set then this page will jump to login page
if (!isset($_SESSION['adminidusername'])) {
        print "
				<script language='javascript'>
					window.location = 'index.php';
				</script>
			";
			
}
$tomake= mysqli_real_escape_string($con,$_GET["username"]);

$result=mysqli_query($con,"UPDATE affiliateuser SET active=0 WHERE username='$tomake'");


//code added by sridhar

$ref_query11=mysqli_query($con,"SELECT  * FROM affiliateuser WHERE username='$tomake'");
$ref_list11=$ref_query11->fetch_array(MYSQLI_ASSOC);
$ref=$ref_list11['referedby'];
$userid=$tomake;
$luser_id=$tomake;
$package=mysqli_real_escape_string($con,$_GET['package']);


$c1=mysqli_query($con,"SELECT  COUNT(*) as STAGETOTUSER FROM affiliate_bonus_history 
 WHERE (user_id = '$userid')");
$c1_list=$c1->fetch_array(MYSQLI_ASSOC);
$c1_count=$c1_list['STAGETOTUSER'];

if($c1_count!=0)
{


	//bonus code decrement starts here
	$q1=mysqli_query($con,"SELECT  * FROM affiliate_bonus_history WHERE (user_id = '$luser_id')");
	$all_list1 = mysqli_fetch_array($q1, MYSQL_ASSOC);
	$ref_bonus_user= $all_list1['stage1_ref'];
	if($ref_bonus_user !=""){
		$qq2=mysqli_query($con,"SELECT  tamount As TotalAmt FROM affiliateuser WHERE username = '$ref_bonus_user'");
		$qrow2=$qq2->fetch_array(MYSQLI_ASSOC);
		$tot_amt2=($qrow2['TotalAmt']-30);
		$qupdate2=mysqli_query($con,"update affiliateuser set tamount='".$tot_amt2."'where username='".$ref_bonus_user."'");	
		
		//stage update
		$st_update2=mysqli_query($con,"update affiliate_bonus_history set stage5_ref='".$ref_bonus_user."'where user_id='".$luser_id."'");		
	}
	
	
	
	 
	$q2=mysqli_query($con,"SELECT  * FROM affiliate_bonus_history WHERE (user_id = '$ref_bonus_user')");
	$all_list2 = mysqli_fetch_array($q2, MYSQL_ASSOC);
	$ref_bonus_user2= $all_list2['stage1_ref'];
	if($ref_bonus_user2 !=""){
		$qq2=mysqli_query($con,"SELECT  tamount As TotalAmt FROM affiliateuser WHERE username = '$ref_bonus_user2'");
		$qrow2=$qq2->fetch_array(MYSQLI_ASSOC);
		$tot_amt2=($qrow2['TotalAmt']-1);
		$qupdate2=mysqli_query($con,"update affiliateuser set tamount='".$tot_amt2."'where username='".$ref_bonus_user2."'");	
		
		//stage update
		$st_update2=mysqli_query($con,"update affiliate_bonus_history set stage5_ref='".$ref_bonus_user2."'where user_id='".$luser_id."'");		
	}

	$q3=mysqli_query($con,"SELECT  * FROM affiliate_bonus_history WHERE (user_id = '$ref_bonus_user2')");
	$all_list3 = mysqli_fetch_array($q3, MYSQL_ASSOC);
	$ref_bonus_user3= $all_list3['stage1_ref'];
	if($ref_bonus_user3 !=""){
		$qq3=mysqli_query($con,"SELECT  tamount As TotalAmt FROM affiliateuser WHERE username = '$ref_bonus_user3'");
		$qrow3=$qq3->fetch_array(MYSQLI_ASSOC);
		$tot_amt3=($qrow3['TotalAmt']-1);
		$qupdate3=mysqli_query($con,"update affiliateuser set tamount='".$tot_amt3."'where username='".$ref_bonus_user3."'");	
	
		//stage update
		$st_update3=mysqli_query($con,"update affiliate_bonus_history set stage4_ref='".$ref_bonus_user3."'where user_id='".$luser_id."'");		
	
	}

	$q4=mysqli_query($con,"SELECT  * FROM affiliate_bonus_history WHERE (user_id = '$ref_bonus_user3')");
	$all_list4 = mysqli_fetch_array($q4, MYSQL_ASSOC);
	$ref_bonus_user4= $all_list4['stage1_ref'];
	if($ref_bonus_user4 !=""){
		$qq4=mysqli_query($con,"SELECT  tamount As TotalAmt FROM affiliateuser WHERE username = '$ref_bonus_user4'");
		$qrow4=$qq4->fetch_array(MYSQLI_ASSOC);
		$tot_amt4=($qrow4['TotalAmt']-1);
		$qupdate4=mysqli_query($con,"update affiliateuser set tamount='".$tot_amt4."'where username='".$ref_bonus_user4."'");	
		
		//stage update
		$st_update4=mysqli_query($con,"update affiliate_bonus_history set stage3_ref='".$ref_bonus_user4."'where user_id='".$luser_id."'");		
	
	}

	$q5=mysqli_query($con,"SELECT  * FROM affiliate_bonus_history WHERE (user_id = '$ref_bonus_user4')");
	$all_list5 = mysqli_fetch_array($q5, MYSQL_ASSOC);
	$ref_bonus_user5= $all_list5['stage1_ref'];
	if($ref_bonus_user5 !=""){
		$qq5=mysqli_query($con,"SELECT  tamount As TotalAmt FROM affiliateuser WHERE username = '$ref_bonus_user5'");
		$qrow5=$qq5->fetch_array(MYSQLI_ASSOC);
		$tot_amt5=($qrow5['TotalAmt']-1);
		$qupdate5=mysqli_query($con,"update affiliateuser set tamount='".$tot_amt5."'where username='".$ref_bonus_user5."'");	
	
		//stage update
		$st_update5=mysqli_query($con,"update affiliate_bonus_history set stage2_ref='".$ref_bonus_user5."'where user_id='".$luser_id."'");		
	
	
	}
	
	$q6=mysqli_query($con,"SELECT  * FROM affiliate_bonus_history WHERE (user_id = '$ref_bonus_user5')");
	$all_list6 = mysqli_fetch_array($q5, MYSQL_ASSOC);
	$ref_bonus_user6= $all_list6['stage1_ref'];
	if($ref_bonus_user6 !=""){
		$qq6=mysqli_query($con,"SELECT  tamount As TotalAmt FROM affiliateuser WHERE username = '$ref_bonus_user6'");
		$qrow6=$qq6->fetch_array(MYSQLI_ASSOC);
		$tot_amt6=($qrow6['TotalAmt']-1);
		$qupdate6=mysqli_query($con,"update affiliateuser set tamount='".$tot_amt5."'where username='".$ref_bonus_user6."'");	
	}
	
	
	
	//bonus code ends here
	
	$result2=mysqli_query($con,"DELETE FROM affiliate_bonus_history WHERE user_id='$tomake'");
}

if ($result)
{
print "<center>Profile Deactivated<br/>Redirecting in 2 seconds...</center>";
}
else
{
print "<center>Action could not be performed, Something went wrong. Check back again<br/>Redirecting in 2 seconds...</center>";
}

?>