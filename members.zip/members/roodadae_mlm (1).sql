-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 23, 2017 at 07:06 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `roodadae_mlm`
--

-- --------------------------------------------------------

--
-- Table structure for table `affiliateuser`
--

CREATE TABLE `affiliateuser` (
  `Id` int(11) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` text NOT NULL,
  `fname` text NOT NULL,
  `address` text NOT NULL,
  `email` text NOT NULL,
  `referedby` varchar(15) NOT NULL DEFAULT 'none',
  `ipaddress` int(10) UNSIGNED NOT NULL,
  `mobile` bigint(10) NOT NULL,
  `active` int(11) NOT NULL,
  `doj` date NOT NULL,
  `country` text NOT NULL,
  `tamount` double NOT NULL DEFAULT '0',
  `payment` varchar(10) NOT NULL,
  `signupcode` text NOT NULL,
  `level` int(1) NOT NULL DEFAULT '2',
  `pcktaken` int(10) NOT NULL DEFAULT '0',
  `launch` int(1) NOT NULL DEFAULT '0',
  `expiry` date NOT NULL DEFAULT '2199-12-31',
  `bankname` varchar(250) NOT NULL DEFAULT 'Not Available',
  `accountname` varchar(250) NOT NULL DEFAULT 'Not Available',
  `accountno` double NOT NULL DEFAULT '0',
  `accounttype` int(11) NOT NULL DEFAULT '0',
  `ifsccode` varchar(100) NOT NULL DEFAULT 'Not Available',
  `getpayment` int(11) NOT NULL DEFAULT '1',
  `renew` int(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `affiliateuser`
--

INSERT INTO `affiliateuser` (`Id`, `username`, `password`, `fname`, `address`, `email`, `referedby`, `ipaddress`, `mobile`, `active`, `doj`, `country`, `tamount`, `payment`, `signupcode`, `level`, `pcktaken`, `launch`, `expiry`, `bankname`, `accountname`, `accountno`, `accounttype`, `ifsccode`, `getpayment`, `renew`) VALUES
(1, 'adminadmin', 'test1234', 'Site Admin', 'Address OF Company Or Individual', 'EmailofAdmin@Domain.com', 'none', 0, 0, 1, '0000-00-00', 'Country', 2900, '', '0', 1, 1, 1, '0000-00-00', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(2, 'roodabatoz', 'test1234', 'roodabatoz', 'Address OF Company Or Individual', 'transfer@roodabatoz.com', 'none', 0, 0, 1, '0000-00-00', 'Country', 30000150, '', '0', 1, 1, 0, '2020-12-25', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(3, 'roodab', 'test1234', 'roodab', 'Hzfvhvh ', 'roodab@gmail.com', 'adminadmin', 457048432, 987654323, 1, '2016-12-31', 'Malaysia', 3, '', '9271000553', 1, 2, 0, '2017-01-29', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(4, 'roodab1', 'R12345678R', 'roodab1', 'Kuala Lumpur', 'sapS1s@gmail.com', 'roodab', 3075354152, 9910345678, 1, '2017-01-01', 'Malaysia', 3, '', '5109683660', 1, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(5, 'roodab2', 'r12345678r', 'roodab2', 'CCvsdfgh', 'fmgh1@yahoo.com', 'roodab1', 3075354152, 4346565, 1, '2017-01-01', 'India', 23, '', '3644780839', 2, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(6, 'roodab3', 'r12345678r', 'roodab3', 'CCvsdfgh', 'fmdgh1@yahoo.com', 'roodab2', 3075354152, 987654321, 1, '2017-01-01', 'India', 0, '', '5357456770', 1, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(7, 'roodab4', 'r12345678r', 'roodab4', 'CCvsdfgh', 'fmddgh1@yahoo.com', 'roodab3', 3075354152, 0, 1, '2017-01-01', 'India', 40, '', '5942512949', 2, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(8, 'roodab5', 'r12345678r', 'roodab5', 'CCvsdfgh', 'fmddgdh1@yahoo.com', 'roodab4', 3075354152, 4565, 1, '2017-01-01', 'India', 90, '', '8936671564', 1, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(9, 'roodab6', 'r12345678r', 'roodab6', 'CCvsdfgh', 'fdh1@yahoo.com', 'roodab5', 3075354152, 45565, 1, '2017-01-01', 'India', 110, '', '7439797181', 1, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(10, 'roodab7', 'r12345678r', 'roodab7', 'CCvsdfgh', 'fdhd1@yahoo.com', 'roodab6', 3075354152, 455645, 1, '2017-01-01', 'India', 259, '', '3328898296', 1, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(11, 'joshuatang', 'fmm*wl391190', 'joshuatang ', 'A-18-11, Desa Sri Puteri (A), Jalan 1/125G, Desa Petaling,  57100 Kuala Lumpur. ', 'cheewahtang8@gmail.com', 'roodab7', 3075354152, 987654321, 1, '2017-01-01', 'Malaysia', 133, '', '3156166171', 1, 2, 0, '2017-01-30', 'Maybank ', 'Tang Chee Wah ', 158314041986, 0, 'MBBEMYKL ', 1, 0),
(12, 'omid', 'r12345678o', 'omid', 'CCvsdfgh', 'fddfhd1@yahoo.com', 'roodab7', 3075354152, 987654321, 1, '2017-01-01', 'Malaysia', 20, '', '8305402348', 3, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(13, 'omid1177', 'r12345678o', 'omidam', 'CCvsdfgh', 'fdddfhd1@yahoo.com', 'roodab7', 3075354152, 987654321, 1, '2017-01-01', 'Malaysia', 0, '', '2211094635', 2, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(14, 'alexpeyman2017', 'aa12345678', 'alexpeyman', 'CCvsdfgh', 'fdsddfhd1@yahoo.com', 'roodab7', 3075354152, 4455554645, 1, '2017-01-01', 'Malaysia', 114, '', '6431597889', 2, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(15, 'kumar', 'r12345678k', 'kumar', 'CCvsdfgh', 'fdsdfdfhd1@yahoo.com', 'joshuatang', 3075354152, 44455554645, 1, '2017-01-01', 'Malaysia', 60, '', '1780688340', 3, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(16, 'arasham', 'r12345678a', 'arasham', 'CCvsdfgh', 'fdsdfdffhd1@yahoo.com', 'joshuatang', 3075354152, 444455554645, 1, '2017-01-01', 'Malaysia', 40, '', '6162613775', 1, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(17, 'leong8835', 'leong1976', 'leong kai loong', 'Desa petaling ', 'Leongkailoonglkl@gmail.com', 'joshuatang', 3075354184, 123179571, 1, '2017-01-01', 'Malaysia', 177, '', '4669323973', 2, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(18, 'angsl102', 'angleong221', 'Siew li Ang ', 'Desa petaling ', 'angsiewli103a@gmail.com', 'leong8835', 3075354184, 1231795700, 1, '2017-01-01', 'Malaysia', 45, '', '7322770539', 3, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(19, 'Roga', 'r12345678', 'Roga', 'CCvsdfgh', 'gffhfd1@yahoo.com', 'joshuatang', 3075354184, 4356454, 1, '2017-01-01', 'Malaysia', 143, '', '3246643783', 1, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(20, 'saidamo', 's12345678', 'saidamo', 'CCvsdfgh', 'gffhffd1@yahoo.com', 'Roga', 3075354184, 4544356454, 1, '2017-01-01', 'Malaysia', 0, '', '5465859836', 2, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(21, 'diamondling', 'd12345678', 'diamondling', 'CCvsdfgh', 'fgffhffd1@yahoo.com', 'joshuatang', 3075354184, 544356454, 1, '2017-01-01', 'Malaysia', 0, '', '4714881653', 2, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(22, 'peyman', 'r12345678p', 'peyman', 'CCvsdfgh', 'fgffdhfffd1@yahoo.com', 'joshuatang', 3075354184, 544359, 1, '2017-01-01', 'Malaysia', 60, '', '8867378818', 1, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(23, 'ahho', 'a12345678a', 'ahho', 'CCvsdfgh', 'fgad1@yahoo.com', 'peyman', 3075354184, 5444359, 1, '2017-01-01', 'Malaysia', 30, '', '1319531102', 2, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(24, 'ahqing', 'a12345678a', 'ahqing', 'CCvsdfgh', 'fgaad1@yahoo.com', 'peyman', 3075354184, 54444359, 1, '2017-01-01', 'Malaysia', 0, '', '1710809026', 2, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(25, 'miaozi', 'a12345678a', 'miaozi', 'CCvsdfgh', 'fgasad1@yahoo.com', 'peyman', 3075354184, 544344359, 1, '2017-01-01', 'Malaysia', 0, '', '3859965519', 2, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(26, 'mahq', 'a12345678a', 'mahq', 'CCvsdfgh', 'fgassad1@yahoo.com', 'peyman', 3075354184, 5444344359, 1, '2017-01-01', 'Malaysia', 0, '', '6304304897', 2, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(27, 'Angelina', 'a12345678a', 'angelina', 'CCvsdfgh', 'fgagssad1@yahoo.com', 'kumar', 3075354184, 554329, 1, '2017-01-01', 'Malaysia', 0, '', '5709168037', 2, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(28, 'mahboo2017', 'm12345678', 'mahboobeh', 'KUALA LUMPUR', 'shirbakhtm@yahoo.com', 'alexpeyman2017', 3075354236, 60182277349, 1, '2017-01-01', 'Malaysia', 33, '', '5067101683', 3, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 1, 'Not Available', 2, 0),
(29, 'arash', 'r12345678', 'arasham', ' rdsadD', 'bgd1@yahoo.com', 'arasham', 3075354210, 1234465, 1, '2017-01-01', 'Malaysia', 30, '', '9972403943', 1, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(30, 'amir', 'a12345678', 'amir', ' rdsadD', 'bdgd1@yahoo.com', 'arasham', 3075354153, 12344465, 1, '2017-01-01', 'Malaysia', 0, '', '9608574786', 2, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(31, 'sailendra025', 's12345678', 'sailendra', ' rdsadD', 'bddd1@yahoo.com', 'arasham', 3075354153, 123544465, 1, '2017-01-01', 'Malaysia', 0, '', '6596232615', 2, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(32, 'bhavana', 'b12345678', 'bhavana', ' rdsadD', 'bdddd1@yahoo.com', 'kumar', 3075354153, 1243544465, 1, '2017-01-01', 'Malaysia', 0, '', '2209650025', 2, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(33, 'wasim', 'w12345678', 'wasim', ' rdsadD', 'bdddfd1@yahoo.com', 'arash', 3075354153, 12434544465, 1, '2017-01-01', 'India', 10, '', '4627189632', 1, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(34, 'mehdi38', 'm12345678', 'mehdi', ' rdsadD', 'bdddffd1@yahoo.com', 'alexpeyman2017', 3075354153, 5465, 1, '2017-01-01', 'Malaysia', 30, '', '9765973674', 3, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(35, 'tehrani', '12345678', 'mehdi38', 'Mont Kiara', 'tehrani8888@gmail.com', 'omid', 1023805081, 142348831, 0, '2017-01-01', 'Malaysia', 0, '', '9828563431', 2, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(36, 'shafie', 'a12345678s', 'shafie', 'KUALA LUMPUR', 'bddd1@yahoo.com', 'arash', 3075354132, 5346565765, 1, '2017-01-01', 'Malaysia', 10, '', '5657867929', 1, 2, 0, '2017-01-30', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(39, 'joshuatang2', 'j12345678', 'Tang Chee Wah ', 'A-18-11, Desa Sri Puteri (A), Jalan 1/125G, Desa Petaling,  57100 Kuala Lumpur. ', 'cheewahtang18@gmail.com', 'joshuatang', 3075354313, 108323456, 1, '2017-01-02', 'Malaysia', 379, '', '9657345716', 1, 2, 0, '2017-01-31', 'Maybank ', 'Tang Chee Wah ', 158314041986, 0, 'MBBEMYKL ', 2, 0),
(40, 'joshuatang3', 'j12345678', 'Tang Chee Wah ', 'A-18-11, Desa Sri Puteri (A), Jalan 1/125G, Desa Petaling,  57100 Kuala Lumpur. ', 'cheewahtang28@gmail.com', 'joshuatang', 3075354313, 108323456, 1, '2017-01-02', 'Malaysia', 413, '', '6477642518', 1, 2, 0, '2017-01-31', 'Maybank ', 'Tang Chee Wah ', 158314041986, 2, 'MBBEMYKL ', 2, 0),
(38, 'hadihh', '12345678', '12345678', 'CCvsdfgh', 'ahgfd2@yahoo.com', 'omid1177', 3075354313, 4384656556, 0, '2017-01-02', 'Algeria', 0, '', '6107005327', 2, 2, 0, '2017-01-31', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(41, 'joshuatang4', 'j12345678', 'Tang Chee Wah ', 'A-18-11, Desa Sri Puteri (A), Jalan 1/125G, Desa Petaling,  57100 Kuala Lumpur. ', 'cheewahtang38@gmail.com', 'joshuatang', 3075354313, 108323456, 1, '2017-01-02', 'Malaysia', 366, '', '7022139641', 3, 2, 0, '2017-01-31', 'Maybank ', 'Tang Chee Wah ', 158314041986, 2, 'MBBEMYKL ', 2, 0),
(42, 'iman', 'i12345678', 'iman', 'CCvsdfgh', 'ahddgfdd2@yahoo.com', 'alexpeyman2017', 3075354313, 4384656427, 1, '2017-01-02', 'Malaysia', 0, '', '5331214844', 2, 2, 0, '2017-01-31', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(43, 'Sophiahui', 's12345678', 'Hui Lee Hong ', 'A-18-11, Desa Sri Puteri (A), Jalan 1/125G, Desa Petaling,  57100 Kuala Lumpur. ', 'huileehong@gmail.com', 'Joshuatang2', 3075353775, 1221298237, 1, '2017-01-02', 'Malaysia', 0, '', '1738293092', 2, 2, 0, '2017-01-31', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(44, 'million', 'r12345678r', 'millionaire', 'CCvsdfgh', 'ahddsgfdd2@yahoo.com', 'roodab3', 3075354172, 438465642, 1, '2017-01-02', 'Malaysia', 170, '', '1996960288', 2, 2, 0, '2017-01-31', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(45, 'Leong88351', 'leong1976', 'Leong kai loong', 'Seri kembangan', 'Leongkailoonglkl@gmail.com', 'Leong8835', 1909633671, 1231795716, 0, '2017-01-02', 'Malaysia', 0, '', '2752161282', 2, 2, 0, '2017-01-31', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(46, 'Leong88352', 'leong1976', 'Leong Kai loong ', 'Desa petaling', 'leongkailoonglkl@gmail.com', 'Leong8835', 1009916507, 1231795716, 0, '2017-01-02', 'Malaysia', 0, '', '1600498809', 2, 2, 0, '2017-01-31', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(48, 'acashafie', 'ACCA1331', 'Mohd Shafie Bin Sabtu', 'CCvsdfgh', 'acashafie72@gmail.com', 'Shafie', 3075354136, 1937927876, 1, '2017-01-03', 'Malaysia', 0, '', '2270002812', 2, 2, 0, '2017-02-01', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(49, 'neracagemilang', 'n12345678', 'neracagemilang', 'CCvsdfgh', 'neracagemilang@gmail.com', 'arash', 3075354136, 19379275587, 1, '2017-01-03', 'Malaysia', 0, '', '6216655489', 2, 2, 0, '2017-02-01', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(50, 'Junxian', 's12345678', 'See jun xian', 'Kuantan,Pahang.', 'junxian1989@gmail.com', 'Leong8835', 1010046723, 1036690286, 0, '2017-01-03', 'Malaysia', 0, '', '1946885374', 2, 2, 0, '2017-02-01', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(51, 'Leong88353', 'leong1976', 'Leong kai loong', 'Seri kembangan', 'leongkailoong1976@gmail.com', 'Leong8835', 1010046723, 1231795716, 0, '2017-01-03', 'Malaysia', 0, '', '4518213441', 2, 2, 0, '2017-02-01', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(52, 'Tony22', '12345678', 'Tony yong gian yen', 'KUALA LUMPUR', 'tonyyong63@gmail.com', 'Leong8835', 1010046723, 1222666688, 0, '2017-01-03', 'Malaysia', 0, '', '4749228263', 2, 2, 0, '2017-02-01', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(53, 'Leong88354', 'leong1976', 'Leong kai loong', 'Selangor', 'leongkailoonglkl@gmail.com', 'Leong8835', 1010046723, 1231795716, 0, '2017-01-03', 'Malaysia', 0, '', '6506389743', 2, 2, 0, '2017-02-01', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(54, 'Nicole20', '88889999', 'Chik kam lan', 'Desa petaling', 'chik63967103@gmail.com', 'Leong8835', 1010046723, 1266867188, 1, '2017-01-03', 'Malaysia', 0, '', '4065200317', 2, 2, 0, '2017-02-01', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(55, 'Govind', 'g12345678', 'govin', 'CCvsdfgh', 'gff81@gmail.com', 'roodab6', 3075354231, 5456789, 1, '2017-01-05', 'India', 0, '', '1754756669', 2, 2, 0, '2017-02-03', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(56, 'Lisanawi', '12345678', 'Lisa Nawi Anak Unggang ', 'KUALA LUMPUR', 'liza@gmail.com', 'Joshuatang2', 3411169356, 1639124322, 1, '2017-01-06', 'Malaysia', 0, '', '5573192180', 2, 2, 0, '2017-02-12', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(57, 'Kanlin93', 'k12345678', 'Tang Kan Lin ', 'A-18-11, Desa Sri Puteri (A), Jalan 1/125G, Desa Petaling,  57100 Kuala Lumpur. ', 'kanlin1993@gmail.com', 'Joshuatang2', 3075353736, 1797793522, 1, '2017-01-07', 'Malaysia', 0, '', '7176263344', 2, 2, 0, '2017-02-09', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(58, 'Teressatang', 't12345678', 'Teressa Tang ', 'A-18-11, Desa Sri Puteri (A), Jalan 1/125G, Desa Petaling,  57100 Kuala Lumpur. ', 'teressatang@gmail.com', 'Joshuatang3 ', 3075353736, 1083230233, 1, '2017-01-07', 'Malaysia', 0, '', '9980463563', 2, 2, 0, '2017-02-09', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(59, 'Soongweng', 's12345678', 'Tang Soong Weng ', 'A-18-11, Desa Sri Puteri (A), Jalan 1/125G, Desa Petaling,  57100 Kuala Lumpur. ', 'tangsoongweng@gmail.com', 'Joshuatang4 ', 3075353736, 1822536455, 1, '2017-01-07', 'Malaysia', 0, '', '5376238599', 2, 2, 0, '2017-02-09', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(69, 'r1234', 'r12345678', 'Rrrrrdab', 'CCvsdfgh', 'omepy81@gmail.com', 'roodab1', 3075354333, 46789, 1, '2017-01-12', 'French Guiana', 3, '', '4798100814', 1, 2, 0, '2017-02-14', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(60, 'said2017', 's12345678', 'said', 'KUALA LUMPUR', 'fds1@gmail.com', 'alexpeyman2017', 3075354124, 3256789657, 1, '2017-01-08', 'Malaysia', 10, '', '5207716830', 1, 2, 0, '2017-02-10', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(61, 'Amiran', '987654321', 'Amir bozorg', 'Hcagfggvjhgbbcxffv', 'bozorg77@gmail.com', 'Said2017', 1909633340, 176205307, 1, '2017-01-08', 'Malaysia', 0, '', '1662480570', 2, 2, 0, '2017-02-10', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(73, 'Leong1', 'leong1976', 'Leong Kai loong', 'Desa petaling ', 'leong8835@gmail.com', 'Leong8835', 1909620702, 123179571, 1, '2017-01-16', 'Malaysia', 0, '', '5405889331', 2, 2, 0, '2017-02-18', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(63, 'Leong2', 'leong1976', 'Leong kai loong', 'Selangor', 'leong8835@gmail.com', 'Leong8835', 1009916491, 123179571, 1, '2017-01-08', 'Malaysia', 3, '', '8190470395', 1, 2, 0, '2017-02-10', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(64, 'Tonny6666', '22226666', 'Tony yong gian yen', 'Selangor', 'tonyyong63@gmail.com', 'Leong8835', 1009916491, 122266668, 1, '2017-01-08', 'Malaysia', 0, '', '2223927150', 2, 2, 0, '2017-02-10', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(65, 'Michael1318', '13181318', 'Mok kok keng', 'Kuala Lumpur ', 'mokkokkeng1318@gmail.com', 'Leong8835', 1009916491, 126891318, 1, '2017-01-08', 'Malaysia', 0, '', '7180040491', 2, 2, 0, '2017-02-10', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(66, 'Kuanming1', '12345678', 'Shi Kuan ming ', 'Desa petaling ', 'mingshi982@gmail.com', 'Leong8835', 1009916491, 169699897, 1, '2017-01-08', 'Malaysia', 0, '', '7473688477', 2, 2, 0, '2017-02-10', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(67, 'Whitenger1', '12345678', 'Wong yik pey', 'Pudu ', 'whiteng@gmail.com', 'Leong8835', 1009916491, 166562669, 1, '2017-01-08', 'Malaysia', 0, '', '4618942141', 2, 2, 0, '2017-02-10', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(68, 'Jasonleong1', '12345678', 'Leong Chee wah', 'Desa petaling ', 'jasonlcw77@gmail.com', 'Leong8835', 1009916491, 163111817, 1, '2017-01-08', 'Malaysia', 0, '', '3919837338', 2, 2, 0, '2017-02-10', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(70, 'r12345', 'r12345678', 'rrrrrb', 'CCvsdfgh', 'dppy81@gmail.com', 'r1234', 3075354333, 5456789, 1, '2017-01-12', 'American Samoa', 0, '', '9190025043', 2, 2, 0, '2017-02-14', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0),
(72, 'narges85', 'n12345678', 'nargeshasanianvar', 'RB-13-5,Rivercity condo,Jalan Ipoh,Batu 3', 'narges_hasanianvar85@yahoo.com', 'mahboo2017', 1938051919, 1139378524, 1, '2017-01-16', 'Malaysia', 0, '', '4180129683', 2, 2, 0, '2017-02-18', 'Not Available', 'Not Available', 0, 0, 'Not Available', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `affiliate_bonus_history`
--

CREATE TABLE `affiliate_bonus_history` (
  `bid` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `referedby` varchar(50) NOT NULL,
  `stage1_ref` varchar(30) DEFAULT NULL,
  `stage2_ref` varchar(30) DEFAULT NULL,
  `stage3_ref` varchar(30) DEFAULT NULL,
  `stage4_ref` varchar(30) DEFAULT NULL,
  `stage5_ref` varchar(30) DEFAULT NULL,
  `stage6_ref` varchar(225) DEFAULT NULL,
  `stage7_ref` varchar(40) DEFAULT NULL,
  `stage8_ref` varchar(40) DEFAULT NULL,
  `stage9_ref` varchar(40) DEFAULT NULL,
  `stage10_ref` varchar(40) DEFAULT NULL,
  `stage11_ref` varchar(40) DEFAULT NULL,
  `stage12_ref` varchar(40) DEFAULT NULL,
  `stage13_ref` varchar(40) DEFAULT NULL,
  `stage14_ref` varchar(40) DEFAULT NULL,
  `stage15_ref` varchar(40) DEFAULT NULL,
  `stage16_ref` varchar(40) DEFAULT NULL,
  `stage17_ref` varchar(40) DEFAULT NULL,
  `stage18_ref` varchar(40) DEFAULT NULL,
  `stage19_ref` varchar(40) DEFAULT NULL,
  `stage20_ref` varchar(40) DEFAULT NULL,
  `stage21_ref` varchar(40) DEFAULT NULL,
  `stage22_ref` varchar(40) DEFAULT NULL,
  `stage23_ref` varchar(40) DEFAULT NULL,
  `stage24_ref` varchar(40) DEFAULT NULL,
  `stage25_ref` varchar(40) DEFAULT NULL,
  `stage26_ref` varchar(40) DEFAULT NULL,
  `stage27_ref` varchar(40) DEFAULT NULL,
  `stage28_ref` varchar(40) DEFAULT NULL,
  `stage29_ref` varchar(40) DEFAULT NULL,
  `stage30_ref` varchar(40) DEFAULT NULL,
  `stage31_ref` varchar(40) DEFAULT NULL,
  `stage32_ref` varchar(40) DEFAULT NULL,
  `stage33_ref` varchar(40) DEFAULT NULL,
  `stage34_ref` varchar(40) DEFAULT NULL,
  `stage35_ref` varchar(40) DEFAULT NULL,
  `stage36_ref` varchar(40) DEFAULT NULL,
  `stage37_ref` varchar(40) DEFAULT NULL,
  `stage38_ref` varchar(40) DEFAULT NULL,
  `stage39_ref` varchar(40) DEFAULT NULL,
  `stage40_ref` varchar(40) DEFAULT NULL,
  `stage41_ref` varchar(40) DEFAULT NULL,
  `stage42_ref` varchar(40) DEFAULT NULL,
  `stage43_ref` varchar(40) DEFAULT NULL,
  `stage44_ref` varchar(40) DEFAULT NULL,
  `stage45_ref` varchar(40) DEFAULT NULL,
  `stage46_ref` varchar(40) DEFAULT NULL,
  `stage47_ref` varchar(40) DEFAULT NULL,
  `stage48_ref` varchar(40) DEFAULT NULL,
  `stage49_ref` varchar(40) DEFAULT NULL,
  `stage50_ref` varchar(40) DEFAULT NULL,
  `stage51_ref` varchar(40) DEFAULT NULL,
  `stage52_ref` varchar(40) DEFAULT NULL,
  `stage53_ref` varchar(40) DEFAULT NULL,
  `stage54_ref` varchar(40) DEFAULT NULL,
  `stage55_ref` varchar(40) DEFAULT NULL,
  `stage56_ref` varchar(40) DEFAULT NULL,
  `stage57_ref` varchar(40) DEFAULT NULL,
  `stage58_ref` varchar(40) DEFAULT NULL,
  `stage59_ref` varchar(40) DEFAULT NULL,
  `stage60_ref` varchar(40) DEFAULT NULL,
  `stage61_ref` varchar(40) DEFAULT NULL,
  `stage62_ref` varchar(40) DEFAULT NULL,
  `stage63_ref` varchar(40) DEFAULT NULL,
  `stage64_ref` varchar(40) DEFAULT NULL,
  `stage65_ref` varchar(40) DEFAULT NULL,
  `stage66_ref` varchar(40) DEFAULT NULL,
  `stage67_ref` varchar(40) DEFAULT NULL,
  `stage68_ref` varchar(40) DEFAULT NULL,
  `stage69_ref` varchar(40) DEFAULT NULL,
  `stage70_ref` varchar(40) DEFAULT NULL,
  `stage71_ref` varchar(40) DEFAULT NULL,
  `stage72_ref` varchar(40) DEFAULT NULL,
  `stage73_ref` varchar(40) DEFAULT NULL,
  `stage74_ref` varchar(40) DEFAULT NULL,
  `stage75_ref` varchar(40) DEFAULT NULL,
  `stage76_ref` varchar(40) DEFAULT NULL,
  `stage77_ref` varchar(40) DEFAULT NULL,
  `stage78_ref` varchar(40) DEFAULT NULL,
  `stage79_ref` varchar(40) DEFAULT NULL,
  `stage80_ref` varchar(40) DEFAULT NULL,
  `stage81_ref` varchar(40) DEFAULT NULL,
  `stage82_ref` varchar(40) DEFAULT NULL,
  `stage83_ref` varchar(40) DEFAULT NULL,
  `stage84_ref` varchar(40) DEFAULT NULL,
  `stage85_ref` varchar(40) DEFAULT NULL,
  `stage86_ref` varchar(40) DEFAULT NULL,
  `stage87_ref` varchar(40) DEFAULT NULL,
  `stage88_ref` varchar(40) DEFAULT NULL,
  `stage89_ref` varchar(40) DEFAULT NULL,
  `stage90_ref` varchar(40) DEFAULT NULL,
  `stage91_ref` varchar(40) DEFAULT NULL,
  `stage92_ref` varchar(40) DEFAULT NULL,
  `stage93_ref` varchar(40) DEFAULT NULL,
  `stage94_ref` varchar(40) DEFAULT NULL,
  `stage95_ref` varchar(40) DEFAULT NULL,
  `stage96_ref` varchar(40) DEFAULT NULL,
  `stage97_ref` varchar(40) DEFAULT NULL,
  `stage98_ref` varchar(40) DEFAULT NULL,
  `stage99_ref` varchar(40) DEFAULT NULL,
  `stage100_ref` varchar(40) DEFAULT NULL,
  `ref_stage` varchar(10) NOT NULL,
  `amt` varchar(10) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `affiliate_bonus_history`
--

INSERT INTO `affiliate_bonus_history` (`bid`, `user_id`, `referedby`, `stage1_ref`, `stage2_ref`, `stage3_ref`, `stage4_ref`, `stage5_ref`, `stage6_ref`, `stage7_ref`, `stage8_ref`, `stage9_ref`, `stage10_ref`, `stage11_ref`, `stage12_ref`, `stage13_ref`, `stage14_ref`, `stage15_ref`, `stage16_ref`, `stage17_ref`, `stage18_ref`, `stage19_ref`, `stage20_ref`, `stage21_ref`, `stage22_ref`, `stage23_ref`, `stage24_ref`, `stage25_ref`, `stage26_ref`, `stage27_ref`, `stage28_ref`, `stage29_ref`, `stage30_ref`, `stage31_ref`, `stage32_ref`, `stage33_ref`, `stage34_ref`, `stage35_ref`, `stage36_ref`, `stage37_ref`, `stage38_ref`, `stage39_ref`, `stage40_ref`, `stage41_ref`, `stage42_ref`, `stage43_ref`, `stage44_ref`, `stage45_ref`, `stage46_ref`, `stage47_ref`, `stage48_ref`, `stage49_ref`, `stage50_ref`, `stage51_ref`, `stage52_ref`, `stage53_ref`, `stage54_ref`, `stage55_ref`, `stage56_ref`, `stage57_ref`, `stage58_ref`, `stage59_ref`, `stage60_ref`, `stage61_ref`, `stage62_ref`, `stage63_ref`, `stage64_ref`, `stage65_ref`, `stage66_ref`, `stage67_ref`, `stage68_ref`, `stage69_ref`, `stage70_ref`, `stage71_ref`, `stage72_ref`, `stage73_ref`, `stage74_ref`, `stage75_ref`, `stage76_ref`, `stage77_ref`, `stage78_ref`, `stage79_ref`, `stage80_ref`, `stage81_ref`, `stage82_ref`, `stage83_ref`, `stage84_ref`, `stage85_ref`, `stage86_ref`, `stage87_ref`, `stage88_ref`, `stage89_ref`, `stage90_ref`, `stage91_ref`, `stage92_ref`, `stage93_ref`, `stage94_ref`, `stage95_ref`, `stage96_ref`, `stage97_ref`, `stage98_ref`, `stage99_ref`, `stage100_ref`, `ref_stage`, `amt`, `created`) VALUES
(1, 'roodab1', 'roodab', 'roodab', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(2, 'roodab2', 'roodab1', 'roodab1', '', '', '', 'roodab', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(3, 'roodab3', 'roodab2', 'roodab2', '', '', 'roodab', 'roodab1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(4, 'roodab4', 'roodab3', 'roodab3', '', 'roodab', 'roodab1', 'roodab2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(5, 'roodab5', 'roodab4', 'roodab4', 'roodab', 'roodab1', 'roodab2', 'roodab3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(6, 'roodab6', 'roodab5', 'roodab5', 'roodab1', 'roodab2', 'roodab3', 'roodab4', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(7, 'roodab7', 'roodab6', 'roodab6', 'roodab2', 'roodab3', 'roodab4', 'roodab5', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(8, 'joshuatang', 'roodab7', 'roodab7', 'roodab3', 'roodab4', 'roodab5', 'roodab6', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(9, 'omid', 'roodab7', 'roodab7', 'roodab3', 'roodab4', 'roodab5', 'roodab6', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(10, 'omid1177', 'roodab7', 'roodab7', 'roodab3', 'roodab4', 'roodab5', 'roodab6', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(11, 'alexpeyman2017', 'roodab7', 'joshuatang', 'roodab4', 'roodab5', 'roodab6', 'roodab7', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(12, 'kumar', 'joshuatang', 'joshuatang', 'roodab4', 'roodab5', 'roodab6', 'roodab7', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(13, 'arasham', 'joshuatang', 'joshuatang', 'roodab4', 'roodab5', 'roodab6', 'roodab7', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(14, 'leong8835', 'joshuatang', 'alexpeyman2017', 'roodab5', 'roodab6', 'roodab7', 'joshuatang', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(15, 'angsl102', 'leong8835', 'leong8835', 'roodab6', 'roodab7', 'joshuatang', 'alexpeyman2017', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(16, 'Roga', 'joshuatang', 'alexpeyman2017', 'roodab5', 'roodab6', 'roodab7', 'joshuatang', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2', '10', '2017-01-01 00:00:00'),
(17, 'saidamo', 'Roga', 'Roga', 'roodab6', 'roodab7', 'joshuatang', 'alexpeyman2017', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(18, 'diamondling', 'joshuatang', 'alexpeyman2017', 'roodab5', 'roodab6', 'roodab7', 'joshuatang', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2', '10', '2017-01-01 00:00:00'),
(19, 'peyman', 'joshuatang', 'kumar', 'roodab5', 'roodab6', 'roodab7', 'joshuatang', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2', '10', '2017-01-01 00:00:00'),
(20, 'ahho', 'peyman', 'peyman', 'roodab6', 'roodab7', 'joshuatang', 'kumar', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(21, 'ahqing', 'peyman', 'peyman', 'roodab6', 'roodab7', 'joshuatang', 'kumar', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(22, 'miaozi', 'peyman', 'peyman', 'roodab6', 'roodab7', 'joshuatang', 'kumar', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(23, 'mahq', 'peyman', 'ahho', 'roodab7', 'joshuatang', 'kumar', 'peyman', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(24, 'Angelina', 'kumar', 'ahho', 'roodab7', 'joshuatang', 'kumar', 'peyman', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2', '10', '2017-01-01 00:00:00'),
(25, 'mahboo2017', 'alexpeyman2017', 'leong8835', 'roodab6', 'roodab7', 'joshuatang', 'alexpeyman2017', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2', '10', '2017-01-01 00:00:00'),
(26, 'arash', 'arasham', 'arasham', 'roodab5', 'roodab6', 'roodab7', 'joshuatang', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(27, 'amir', 'arasham', 'arasham', 'roodab5', 'roodab6', 'roodab7', 'joshuatang', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(28, 'sailendra025', 'arasham', 'arasham', 'roodab5', 'roodab6', 'roodab7', 'joshuatang', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(29, 'bhavana', 'kumar', 'ahho', 'roodab7', 'joshuatang', 'kumar', 'peyman', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2', '10', '2017-01-01 00:00:00'),
(30, 'wasim', 'arash', 'arash', 'roodab6', 'roodab7', 'joshuatang', 'arasham', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(31, 'mehdi38', 'alexpeyman2017', 'leong8835', 'roodab6', 'roodab7', 'joshuatang', 'alexpeyman2017', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2', '10', '2017-01-01 00:00:00'),
(32, 'shafie', 'arash', 'arash', 'roodab6', 'roodab7', 'joshuatang', 'arasham', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-01 00:00:00'),
(33, 'joshuatang2', 'joshuatang', 'kumar', 'roodab5', 'roodab6', 'roodab7', 'joshuatang', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '3', '10', '2017-01-02 00:00:00'),
(34, 'joshuatang3', 'joshuatang', 'kumar', 'roodab5', 'roodab6', 'roodab7', 'joshuatang', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '3', '10', '2017-01-02 00:00:00'),
(35, 'joshuatang4', 'joshuatang', 'angsl102', 'roodab7', 'joshuatang', 'alexpeyman2017', 'leong8835', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '3', '10', '2017-01-02 00:00:00'),
(36, 'iman', 'alexpeyman2017', 'angsl102', 'roodab7', 'joshuatang', 'alexpeyman2017', 'leong8835', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2', '10', '2017-01-02 00:00:00'),
(37, 'Sophiahui', 'Joshuatang2', 'Joshuatang2', 'roodab6', 'roodab7', 'joshuatang', 'kumar', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-02 00:00:00'),
(38, 'million', 'roodab3', 'roodab4', 'roodab', 'roodab1', 'roodab2', 'roodab3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2', '10', '2017-01-02 00:00:00'),
(40, 'acashafie', 'Shafie', 'Shafie', 'roodab7', 'joshuatang', 'arasham', 'arash', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-03 00:00:00'),
(41, 'neracagemilang', 'arash', 'wasim', 'roodab7', 'joshuatang', 'arasham', 'arash', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-03 00:00:00'),
(42, 'Govind', 'roodab6', 'omid', 'roodab4', 'roodab5', 'roodab6', 'roodab7', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '3', '10', '2017-01-05 00:00:00'),
(43, 'Lisanawi', 'Joshuatang2', 'Joshuatang2', 'roodab6', 'roodab7', 'joshuatang', 'kumar', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-06 00:00:00'),
(44, 'Soongweng', 'Joshuatang4 ', 'Joshuatang4 ', 'joshuatang', 'alexpeyman2017', 'leong8835', 'angsl102', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-07 00:00:00'),
(45, 'Kanlin93', 'Joshuatang2', 'Joshuatang2', 'roodab6', 'roodab7', 'joshuatang', 'kumar', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-07 00:00:00'),
(46, 'Teressatang', 'Joshuatang3 ', 'Joshuatang3 ', 'roodab6', 'roodab7', 'joshuatang', 'kumar', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-07 00:00:00'),
(47, 'said2017', 'alexpeyman2017', 'angsl102', 'roodab7', 'joshuatang', 'alexpeyman2017', 'leong8835', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '3', '10', '2017-01-08 00:00:00'),
(48, 'Amiran', 'Said2017', 'Said2017', 'joshuatang', 'alexpeyman2017', 'leong8835', 'angsl102', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '10', '2017-01-08 00:00:00'),
(49, 'Leong2', 'Leong8835', 'mahboo2017', 'roodab7', 'joshuatang', 'alexpeyman2017', 'leong8835', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2', '10', '2017-01-09 00:00:00'),
(50, 'Jasonleong1', 'Leong8835', 'mahboo2017', 'roodab7', 'joshuatang', 'alexpeyman2017', 'leong8835', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2', '10', '2017-01-09 00:00:00'),
(51, 'Nicole20', 'Leong8835', 'mahboo2017', 'roodab7', 'joshuatang', 'alexpeyman2017', 'leong8835', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '3', '10', '2017-01-09 00:00:00'),
(52, 'Whitenger1', 'Leong8835', 'mehdi38', 'roodab7', 'joshuatang', 'alexpeyman2017', 'leong8835', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '3', '10', '2017-01-09 00:00:00'),
(53, 'Michael1318', 'Leong8835', 'mehdi38', 'roodab7', 'joshuatang', 'alexpeyman2017', 'leong8835', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '3', '10', '2017-01-09 00:00:00'),
(54, 'Kuanming1', 'Leong8835', 'mehdi38', 'roodab7', 'joshuatang', 'alexpeyman2017', 'leong8835', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '3', '10', '2017-01-09 00:00:00'),
(55, 'Tonny6666', 'Leong8835', 'joshuatang4', 'joshuatang', 'alexpeyman2017', 'leong8835', 'angsl102', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '3', '10', '2017-01-09 00:00:00'),
(56, 'r1234', 'roodab1', 'roodab2', '', '', 'roodab', 'roodab1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2', '3', '2017-01-12 00:00:00'),
(57, 'r12345', 'r1234', 'r1234', '', 'roodab', 'roodab1', 'roodab2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '3', '2017-01-12 00:00:00'),
(58, 'narges85', 'mahboo2017', 'Leong2', 'joshuatang', 'alexpeyman2017', 'leong8835', 'mahboo2017', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '3', '2017-01-16 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `affliate_stage_bonus`
--

CREATE TABLE `affliate_stage_bonus` (
  `bonus_id` int(11) NOT NULL,
  `user_id` varchar(200) NOT NULL,
  `ref_by` varchar(200) NOT NULL,
  `upgrade_stage` varchar(100) NOT NULL,
  `upgrade_cost` varchar(20) NOT NULL,
  `bonus_to` varchar(100) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `affliate_stage_bonus`
--

INSERT INTO `affliate_stage_bonus` (`bonus_id`, `user_id`, `ref_by`, `upgrade_stage`, `upgrade_cost`, `bonus_to`, `created_on`) VALUES
(1, 'roodab', 'adminadmin', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(2, 'roodab1', 'roodab', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(3, 'roodab2', 'roodab1', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(4, 'roodab3', 'roodab2', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(5, 'roodab4', 'roodab3', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(6, 'roodab5', 'roodab4', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(7, 'roodab6', 'roodab5', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(8, 'roodab7', 'roodab6', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(9, 'joshuatang', 'roodab7', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(10, 'joshuatang', 'roodab7', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(11, 'joshuatang', 'roodab7', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(12, 'joshuatang', 'roodab7', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(13, 'joshuatang', 'roodab7', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(14, 'alexpeyman2017', 'roodab7', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(15, 'alexpeyman2017', 'roodab7', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(16, 'alexpeyman2017', 'roodab7', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(17, 'alexpeyman2017', 'roodab7', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(18, 'alexpeyman2017', 'roodab7', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(19, 'leong8835', 'joshuatang', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(20, 'alexpeyman2017', 'roodab7', '2', '0', 'adminadmin', '2017-01-01 00:00:00'),
(21, 'alexpeyman2017', 'roodab7', '2', '0', 'adminadmin', '2017-01-01 00:00:00'),
(22, 'alexpeyman2017', 'roodab7', '2', '0', 'adminadmin', '2017-01-01 00:00:00'),
(23, 'alexpeyman2017', 'roodab7', '2', '0', 'adminadmin', '2017-01-01 00:00:00'),
(24, 'alexpeyman2017', 'roodab7', '2', '0', 'adminadmin', '2017-01-01 00:00:00'),
(25, 'Roga', 'joshuatang', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(26, 'kumar', 'joshuatang', '2', '0', 'adminadmin', '2017-01-01 00:00:00'),
(27, 'kumar', 'joshuatang', '2', '0', 'adminadmin', '2017-01-01 00:00:00'),
(28, 'kumar', 'joshuatang', '2', '0', 'adminadmin', '2017-01-01 00:00:00'),
(29, 'kumar', 'joshuatang', '2', '0', 'adminadmin', '2017-01-01 00:00:00'),
(30, 'kumar', 'joshuatang', '2', '0', 'adminadmin', '2017-01-01 00:00:00'),
(31, 'peyman', 'joshuatang', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(32, 'ahho', 'peyman', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(33, 'ahho', 'peyman', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(34, 'ahho', 'peyman', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(35, 'ahho', 'peyman', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(36, 'ahho', 'peyman', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(37, 'ahho', 'peyman', '2', '0', 'adminadmin', '2017-01-01 00:00:00'),
(38, 'ahho', 'peyman', '2', '0', 'adminadmin', '2017-01-01 00:00:00'),
(39, 'ahho', 'peyman', '2', '0', 'adminadmin', '2017-01-01 00:00:00'),
(40, 'ahho', 'peyman', '2', '0', 'adminadmin', '2017-01-01 00:00:00'),
(41, 'ahho', 'peyman', '2', '0', 'adminadmin', '2017-01-01 00:00:00'),
(42, 'leong8835', 'joshuatang', '2', '0', 'adminadmin', '2017-01-01 00:00:00'),
(43, 'leong8835', 'joshuatang', '2', '0', 'adminadmin', '2017-01-01 00:00:00'),
(44, 'leong8835', 'joshuatang', '2', '0', 'adminadmin', '2017-01-01 00:00:00'),
(45, 'leong8835', 'joshuatang', '2', '0', 'adminadmin', '2017-01-01 00:00:00'),
(46, 'leong8835', 'joshuatang', '2', '0', 'adminadmin', '2017-01-01 00:00:00'),
(47, 'arasham', 'joshuatang', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(48, 'arash', 'arasham', '1', '0', 'adminadmin', '2017-01-01 00:00:00'),
(49, 'kumar', 'joshuatang', '3', '0', 'adminadmin', '2017-01-02 00:00:00'),
(50, 'kumar', 'joshuatang', '3', '0', 'adminadmin', '2017-01-02 00:00:00'),
(51, 'kumar', 'joshuatang', '3', '0', 'adminadmin', '2017-01-02 00:00:00'),
(52, 'kumar', 'joshuatang', '3', '0', 'adminadmin', '2017-01-02 00:00:00'),
(53, 'kumar', 'joshuatang', '3', '0', 'adminadmin', '2017-01-02 00:00:00'),
(54, 'angsl102', 'leong8835', '3', '0', 'adminadmin', '2017-01-02 00:00:00'),
(55, 'angsl102', 'leong8835', '3', '0', 'adminadmin', '2017-01-02 00:00:00'),
(56, 'angsl102', 'leong8835', '3', '0', 'adminadmin', '2017-01-02 00:00:00'),
(57, 'angsl102', 'leong8835', '3', '0', 'adminadmin', '2017-01-02 00:00:00'),
(58, 'angsl102', 'leong8835', '3', '0', 'adminadmin', '2017-01-02 00:00:00'),
(59, 'angsl102', 'leong8835', '2', '0', 'adminadmin', '2017-01-02 00:00:00'),
(60, 'angsl102', 'leong8835', '2', '0', 'adminadmin', '2017-01-02 00:00:00'),
(61, 'angsl102', 'leong8835', '2', '0', 'adminadmin', '2017-01-02 00:00:00'),
(62, 'angsl102', 'leong8835', '2', '0', 'adminadmin', '2017-01-02 00:00:00'),
(63, 'angsl102', 'leong8835', '2', '0', 'adminadmin', '2017-01-02 00:00:00'),
(64, 'Joshuatang2', 'joshuatang', '1', '0', 'adminadmin', '2017-01-02 00:00:00'),
(65, 'roodab4', 'roodab3', '2', '0', 'adminadmin', '2017-01-02 00:00:00'),
(66, 'roodab4', 'roodab3', '2', '0', 'adminadmin', '2017-01-02 00:00:00'),
(67, 'roodab4', 'roodab3', '2', '0', 'adminadmin', '2017-01-02 00:00:00'),
(68, 'roodab4', 'roodab3', '2', '0', 'adminadmin', '2017-01-02 00:00:00'),
(69, 'roodab4', 'roodab3', '2', '0', 'adminadmin', '2017-01-02 00:00:00'),
(70, 'Shafie', 'arash', '1', '0', 'adminadmin', '2017-01-03 00:00:00'),
(71, 'wasim', 'arash', '1', '0', 'adminadmin', '2017-01-03 00:00:00'),
(72, 'wasim', 'arash', '1', '0', 'adminadmin', '2017-01-03 00:00:00'),
(73, 'wasim', 'arash', '1', '0', 'adminadmin', '2017-01-03 00:00:00'),
(74, 'wasim', 'arash', '1', '0', 'adminadmin', '2017-01-03 00:00:00'),
(75, 'wasim', 'arash', '1', '0', 'adminadmin', '2017-01-03 00:00:00'),
(76, 'omid', 'roodab7', '3', '0', 'adminadmin', '2017-01-05 00:00:00'),
(77, 'omid', 'roodab7', '3', '0', 'adminadmin', '2017-01-05 00:00:00'),
(78, 'omid', 'roodab7', '3', '0', 'adminadmin', '2017-01-05 00:00:00'),
(79, 'omid', 'roodab7', '3', '0', 'adminadmin', '2017-01-05 00:00:00'),
(80, 'omid', 'roodab7', '3', '0', 'adminadmin', '2017-01-05 00:00:00'),
(81, 'Joshuatang4 ', 'joshuatang', '1', '0', 'adminadmin', '2017-01-07 00:00:00'),
(82, 'Joshuatang3 ', 'joshuatang', '1', '0', 'adminadmin', '2017-01-07 00:00:00'),
(83, 'Said2017', 'alexpeyman2017', '1', '0', 'adminadmin', '2017-01-08 00:00:00'),
(84, 'mahboo2017', 'alexpeyman2017', '2', '0', 'adminadmin', '2017-01-09 00:00:00'),
(85, 'mahboo2017', 'alexpeyman2017', '2', '0', 'adminadmin', '2017-01-09 00:00:00'),
(86, 'mahboo2017', 'alexpeyman2017', '2', '0', 'adminadmin', '2017-01-09 00:00:00'),
(87, 'mahboo2017', 'alexpeyman2017', '2', '0', 'adminadmin', '2017-01-09 00:00:00'),
(88, 'mahboo2017', 'alexpeyman2017', '2', '0', 'adminadmin', '2017-01-09 00:00:00'),
(89, 'mahboo2017', 'alexpeyman2017', '3', '0', 'adminadmin', '2017-01-09 00:00:00'),
(90, 'mahboo2017', 'alexpeyman2017', '3', '0', 'adminadmin', '2017-01-09 00:00:00'),
(91, 'mahboo2017', 'alexpeyman2017', '3', '0', 'adminadmin', '2017-01-09 00:00:00'),
(92, 'mahboo2017', 'alexpeyman2017', '3', '0', 'adminadmin', '2017-01-09 00:00:00'),
(93, 'mahboo2017', 'alexpeyman2017', '3', '0', 'adminadmin', '2017-01-09 00:00:00'),
(94, 'mehdi38', 'alexpeyman2017', '3', '0', 'adminadmin', '2017-01-09 00:00:00'),
(95, 'mehdi38', 'alexpeyman2017', '3', '0', 'adminadmin', '2017-01-09 00:00:00'),
(96, 'mehdi38', 'alexpeyman2017', '3', '0', 'adminadmin', '2017-01-09 00:00:00'),
(97, 'mehdi38', 'alexpeyman2017', '3', '0', 'adminadmin', '2017-01-09 00:00:00'),
(98, 'mehdi38', 'alexpeyman2017', '3', '0', 'adminadmin', '2017-01-09 00:00:00'),
(99, 'joshuatang4', 'joshuatang', '3', '0', 'adminadmin', '2017-01-09 00:00:00'),
(100, 'joshuatang4', 'joshuatang', '3', '0', 'adminadmin', '2017-01-09 00:00:00'),
(101, 'joshuatang4', 'joshuatang', '3', '0', 'adminadmin', '2017-01-09 00:00:00'),
(102, 'joshuatang4', 'joshuatang', '3', '0', 'adminadmin', '2017-01-09 00:00:00'),
(103, 'joshuatang4', 'joshuatang', '3', '0', 'adminadmin', '2017-01-09 00:00:00'),
(104, 'roodab2', 'roodab1', '2', '0', 'adminadmin', '2017-01-12 00:00:00'),
(105, 'roodab2', 'roodab1', '2', '0', 'adminadmin', '2017-01-12 00:00:00'),
(106, 'roodab2', 'roodab1', '2', '0', 'adminadmin', '2017-01-12 00:00:00'),
(107, 'roodab2', 'roodab1', '2', '0', 'adminadmin', '2017-01-12 00:00:00'),
(108, 'roodab2', 'roodab1', '2', '0', 'adminadmin', '2017-01-12 00:00:00'),
(109, 'r1234', 'roodab1', '1', '0', 'adminadmin', '2017-01-12 00:00:00'),
(110, 'Leong2', 'Leong8835', '1', '0', 'adminadmin', '2017-01-16 00:00:00'),
(111, 'Leong2', 'Leong8835', '1', '0', 'adminadmin', '2017-01-16 00:00:00'),
(112, 'Leong2', 'Leong8835', '1', '0', 'adminadmin', '2017-01-16 00:00:00'),
(113, 'Leong2', 'Leong8835', '1', '0', 'adminadmin', '2017-01-16 00:00:00'),
(114, 'Leong2', 'Leong8835', '1', '0', 'adminadmin', '2017-01-16 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE `banners` (
  `bannerid` double NOT NULL,
  `bannerdesc` varchar(100) NOT NULL,
  `bannerhtml` text NOT NULL,
  `banneractive` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `currency`
--

CREATE TABLE `currency` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `code` text NOT NULL,
  `comment` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `currency`
--

INSERT INTO `currency` (`id`, `name`, `code`, `comment`) VALUES
(1, 'US Doller', 'USD', ''),
(2, 'Australian Dollar', 'AUD', ''),
(3, 'Brazilian Real', 'BRL', ''),
(4, 'Canadian Dollar', 'CAD', ''),
(5, 'Czech Koruna', 'CZK', ''),
(6, 'Danish Krone', 'DKK', ''),
(7, 'Euro', 'EUR', ''),
(8, 'Thai Baht', 'THB', ''),
(9, 'Hong Kong Dollar', 'HKD', ''),
(10, 'Hungarian Forint', 'HUF', ''),
(11, 'Israeli New Sheqel', 'ILS', ''),
(12, 'Japanese Yen', 'JPY', ''),
(13, 'Malaysian Ringgit', 'MYR', ''),
(14, 'Mexican Peso', 'MXN', ''),
(15, 'Norwegian Krone', 'NOK', ''),
(16, 'New Zealand Dollar', 'NZD', ''),
(17, 'Philippine Peso', 'PHP', ''),
(18, 'Polish Zloty ', 'PLN', ''),
(19, 'Pound Sterling', 'GBP', ''),
(20, 'Russian Ruble', 'RUB', ''),
(21, 'Singapore Dollar', 'SGD', ''),
(22, 'Swedish Krona', 'SEK', ''),
(23, 'Swiss Franc', 'CHF', ''),
(24, 'Taiwan New Dollar', 'TWD', ''),
(26, 'Turkish Lira', 'TRY', '');

-- --------------------------------------------------------

--
-- Table structure for table `emailtext`
--

CREATE TABLE `emailtext` (
  `id` int(6) NOT NULL,
  `code` varchar(50) NOT NULL,
  `etext` text NOT NULL,
  `emailactive` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emailtext`
--

INSERT INTO `emailtext` (`id`, `code`, `etext`, `emailactive`) VALUES
(1, 'SIGNUP', 'This email is the confirmation for your order you have just signed up. Thank you for your interest. Our team welcomes you to our website. \n\nRegards\nTeam MLM Marketing', 1),
(2, 'FORGOTPASSWORD', 'Hi, \nYou have requested a password on our website and therefore we have sent the password on this email. If you haven''t do it please ignore the email.\n\nRegards\nTeam MLM Marketing', 1),
(5, 'NEWMEMBER', 'You have got new order, bingo!', 1),
(6, 'NEWMEMBER', 'You have got new order, bingo!', 1),
(7, 'SIGNUP', 'This email is the confirmation for your order you have just signed up. Thank you for your interest. Our team welcomes you to our website. \n\nRegards\nTeam MLM Marketing', 1),
(8, 'NEWMEMBER', 'You have got new order, bingo!', 1),
(9, 'SIGNUP', 'This email is the confirmation for your order you have just signed up. Thank you for your interest. Our team welcomes you to our website. \n\nRegards\nTeam MLM Marketing', 1),
(10, 'NEWMEMBER', 'You have got new order, bingo!', 1),
(11, 'SIGNUP', 'This email is the confirmation for your order you have just signed up. Thank you for your interest. Our team welcomes you to our website. \n\nRegards\nTeam MLM Marketing', 1);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `posteddate` date NOT NULL,
  `valid` int(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `subject`, `body`, `posteddate`, `valid`) VALUES
(14, 'test notification ', 'Details of thesadasdas asdasnotificationsasdasd', '2016-09-04', 1);

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE `packages` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `price` double NOT NULL DEFAULT '0',
  `currency` text NOT NULL,
  `details` text NOT NULL,
  `tax` double NOT NULL DEFAULT '0',
  `mpay` double NOT NULL DEFAULT '0',
  `sbonus` double DEFAULT '0',
  `cdate` date NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1',
  `level1` double NOT NULL DEFAULT '0',
  `stage1_up` double NOT NULL DEFAULT '0',
  `level2` double NOT NULL DEFAULT '0',
  `stage2_up` double NOT NULL DEFAULT '0',
  `level3` double NOT NULL DEFAULT '0',
  `stage3_up` double NOT NULL DEFAULT '0',
  `level4` double NOT NULL DEFAULT '0',
  `stage4_up` double NOT NULL DEFAULT '0',
  `level5` double NOT NULL DEFAULT '0',
  `stage5_up` double NOT NULL DEFAULT '0',
  `level6` double NOT NULL DEFAULT '0',
  `level7` double NOT NULL DEFAULT '0',
  `level8` double NOT NULL DEFAULT '0',
  `level9` double NOT NULL DEFAULT '0',
  `level10` double NOT NULL DEFAULT '0',
  `level11` double NOT NULL DEFAULT '0',
  `level12` double NOT NULL DEFAULT '0',
  `level13` double NOT NULL DEFAULT '0',
  `level14` double NOT NULL DEFAULT '0',
  `level15` double NOT NULL DEFAULT '0',
  `level16` double NOT NULL DEFAULT '0',
  `level17` double NOT NULL DEFAULT '0',
  `level18` double NOT NULL DEFAULT '0',
  `level19` double NOT NULL DEFAULT '0',
  `level20` double NOT NULL DEFAULT '0',
  `level21` double NOT NULL DEFAULT '0',
  `level22` double NOT NULL DEFAULT '0',
  `level23` double NOT NULL DEFAULT '0',
  `level24` double NOT NULL DEFAULT '0',
  `level25` double NOT NULL DEFAULT '0',
  `level26` double NOT NULL DEFAULT '0',
  `level27` double NOT NULL DEFAULT '0',
  `level28` double NOT NULL DEFAULT '0',
  `level29` double NOT NULL DEFAULT '0',
  `level30` double NOT NULL DEFAULT '0',
  `level31` double NOT NULL DEFAULT '0',
  `level32` double NOT NULL DEFAULT '0',
  `level33` double NOT NULL DEFAULT '0',
  `level34` double NOT NULL DEFAULT '0',
  `level35` double NOT NULL DEFAULT '0',
  `level36` double NOT NULL DEFAULT '0',
  `level37` double NOT NULL DEFAULT '0',
  `level38` double NOT NULL DEFAULT '0',
  `level39` double NOT NULL DEFAULT '0',
  `level40` double NOT NULL DEFAULT '0',
  `level41` double NOT NULL DEFAULT '0',
  `level42` double NOT NULL DEFAULT '0',
  `level43` double NOT NULL DEFAULT '0',
  `level44` double NOT NULL DEFAULT '0',
  `level45` double NOT NULL DEFAULT '0',
  `level46` double NOT NULL DEFAULT '0',
  `level47` double NOT NULL DEFAULT '0',
  `level48` double NOT NULL DEFAULT '0',
  `level49` double NOT NULL DEFAULT '0',
  `level50` double NOT NULL DEFAULT '0',
  `level51` double NOT NULL DEFAULT '0',
  `level52` double NOT NULL DEFAULT '0',
  `level53` double NOT NULL DEFAULT '0',
  `level54` double NOT NULL DEFAULT '0',
  `level55` double NOT NULL DEFAULT '0',
  `level56` double NOT NULL DEFAULT '0',
  `level57` double NOT NULL DEFAULT '0',
  `level58` double NOT NULL DEFAULT '0',
  `level59` double NOT NULL DEFAULT '0',
  `level60` double NOT NULL DEFAULT '0',
  `level61` double NOT NULL DEFAULT '0',
  `level62` double NOT NULL DEFAULT '0',
  `level63` double NOT NULL DEFAULT '0',
  `level64` double NOT NULL DEFAULT '0',
  `level65` double NOT NULL DEFAULT '0',
  `level66` double NOT NULL DEFAULT '0',
  `level67` double NOT NULL DEFAULT '0',
  `level68` double NOT NULL DEFAULT '0',
  `level69` double NOT NULL DEFAULT '0',
  `level70` double NOT NULL DEFAULT '0',
  `level71` double NOT NULL DEFAULT '0',
  `level72` double NOT NULL DEFAULT '0',
  `level73` double NOT NULL DEFAULT '0',
  `level74` double NOT NULL DEFAULT '0',
  `level75` double NOT NULL DEFAULT '0',
  `level76` double NOT NULL DEFAULT '0',
  `level77` double NOT NULL DEFAULT '0',
  `level78` double NOT NULL DEFAULT '0',
  `level79` double NOT NULL DEFAULT '0',
  `level80` double NOT NULL DEFAULT '0',
  `level81` double NOT NULL DEFAULT '0',
  `level82` double NOT NULL DEFAULT '0',
  `level83` double NOT NULL DEFAULT '0',
  `level84` double NOT NULL DEFAULT '0',
  `level85` double NOT NULL DEFAULT '0',
  `level86` double NOT NULL DEFAULT '0',
  `level87` double NOT NULL DEFAULT '0',
  `level88` double NOT NULL DEFAULT '0',
  `level89` double NOT NULL DEFAULT '0',
  `level90` double NOT NULL DEFAULT '0',
  `level91` double NOT NULL DEFAULT '0',
  `level92` double NOT NULL DEFAULT '0',
  `level93` double NOT NULL DEFAULT '0',
  `level94` double NOT NULL DEFAULT '0',
  `level95` double NOT NULL DEFAULT '0',
  `level96` double NOT NULL DEFAULT '0',
  `level97` double NOT NULL DEFAULT '0',
  `level98` double NOT NULL DEFAULT '0',
  `level99` double NOT NULL DEFAULT '0',
  `level100` double NOT NULL DEFAULT '0',
  `stage6_up` double NOT NULL DEFAULT '0',
  `stage7_up` double NOT NULL DEFAULT '0',
  `stage8_up` double NOT NULL DEFAULT '0',
  `stage9_up` double NOT NULL DEFAULT '0',
  `stage10_up` double NOT NULL DEFAULT '0',
  `stage11_up` double NOT NULL DEFAULT '0',
  `stage12_up` double NOT NULL DEFAULT '0',
  `stage13_up` double NOT NULL DEFAULT '0',
  `stage14_up` double NOT NULL DEFAULT '0',
  `stage15_up` double NOT NULL DEFAULT '0',
  `stage16_up` double NOT NULL DEFAULT '0',
  `stage17_up` double NOT NULL DEFAULT '0',
  `stage18_up` double NOT NULL DEFAULT '0',
  `stage19_up` double NOT NULL DEFAULT '0',
  `stage20_up` double NOT NULL DEFAULT '0',
  `stage21_up` double NOT NULL DEFAULT '0',
  `stage22_up` double NOT NULL DEFAULT '0',
  `stage23_up` double NOT NULL DEFAULT '0',
  `stage24_up` double NOT NULL DEFAULT '0',
  `stage25_up` double NOT NULL DEFAULT '0',
  `stage26_up` double NOT NULL DEFAULT '0',
  `stage27_up` double NOT NULL DEFAULT '0',
  `stage28_up` double NOT NULL DEFAULT '0',
  `stage29_up` double NOT NULL DEFAULT '0',
  `stage30_up` double NOT NULL DEFAULT '0',
  `stage31_up` double NOT NULL DEFAULT '0',
  `stage32_up` double NOT NULL DEFAULT '0',
  `stage33_up` double NOT NULL DEFAULT '0',
  `stage34_up` double NOT NULL DEFAULT '0',
  `stage35_up` double NOT NULL DEFAULT '0',
  `stage36_up` double NOT NULL DEFAULT '0',
  `stage37_up` double NOT NULL DEFAULT '0',
  `stage38_up` double NOT NULL DEFAULT '0',
  `stage39_up` double NOT NULL DEFAULT '0',
  `stage40_up` double NOT NULL DEFAULT '0',
  `stage41_up` double NOT NULL DEFAULT '0',
  `stage42_up` double NOT NULL DEFAULT '0',
  `stage43_up` double NOT NULL DEFAULT '0',
  `stage44_up` double NOT NULL DEFAULT '0',
  `stage45_up` double NOT NULL DEFAULT '0',
  `stage46_up` double NOT NULL DEFAULT '0',
  `stage47_up` double NOT NULL DEFAULT '0',
  `stage48_up` double NOT NULL DEFAULT '0',
  `stage49_up` double NOT NULL DEFAULT '0',
  `stage50_up` double NOT NULL DEFAULT '0',
  `stage51_up` double NOT NULL DEFAULT '0',
  `stage52_up` double NOT NULL DEFAULT '0',
  `stage53_up` double NOT NULL DEFAULT '0',
  `stage54_up` double NOT NULL DEFAULT '0',
  `stage55_up` double NOT NULL DEFAULT '0',
  `stage56_up` double NOT NULL DEFAULT '0',
  `stage57_up` double NOT NULL DEFAULT '0',
  `stage58_up` double NOT NULL DEFAULT '0',
  `stage59_up` double NOT NULL DEFAULT '0',
  `stage60_up` double NOT NULL DEFAULT '0',
  `stage61_up` double NOT NULL DEFAULT '0',
  `stage62_up` double NOT NULL DEFAULT '0',
  `stage63_up` double NOT NULL DEFAULT '0',
  `stage64_up` double NOT NULL DEFAULT '0',
  `stage65_up` double NOT NULL DEFAULT '0',
  `stage66_up` double NOT NULL DEFAULT '0',
  `stage67_up` double NOT NULL DEFAULT '0',
  `stage68_up` double NOT NULL DEFAULT '0',
  `stage69_up` double NOT NULL DEFAULT '0',
  `stage70_up` double NOT NULL DEFAULT '0',
  `stage71_up` double NOT NULL DEFAULT '0',
  `stage72_up` double NOT NULL DEFAULT '0',
  `stage73_up` double NOT NULL DEFAULT '0',
  `stage74_up` double NOT NULL DEFAULT '0',
  `stage75_up` double NOT NULL DEFAULT '0',
  `stage76_up` double NOT NULL DEFAULT '0',
  `stage77_up` double NOT NULL DEFAULT '0',
  `stage78_up` double NOT NULL DEFAULT '0',
  `stage79_up` double NOT NULL DEFAULT '0',
  `stage80_up` double NOT NULL DEFAULT '0',
  `stage81_up` double NOT NULL DEFAULT '0',
  `stage82_up` double NOT NULL DEFAULT '0',
  `stage83_up` double NOT NULL DEFAULT '0',
  `stage84_up` double NOT NULL DEFAULT '0',
  `stage85_up` double NOT NULL DEFAULT '0',
  `stage86_up` double NOT NULL DEFAULT '0',
  `stage87_up` double NOT NULL DEFAULT '0',
  `stage88_up` double NOT NULL DEFAULT '0',
  `stage89_up` double NOT NULL DEFAULT '0',
  `stage90_up` double NOT NULL DEFAULT '0',
  `stage91_up` double NOT NULL DEFAULT '0',
  `stage92_up` double NOT NULL DEFAULT '0',
  `stage93_up` double NOT NULL DEFAULT '0',
  `stage94_up` double NOT NULL DEFAULT '0',
  `stage95_up` double NOT NULL DEFAULT '0',
  `stage96_up` double NOT NULL DEFAULT '0',
  `stage97_up` double NOT NULL DEFAULT '0',
  `stage98_up` double NOT NULL DEFAULT '0',
  `stage99_up` double NOT NULL DEFAULT '0',
  `stage100_up` double NOT NULL DEFAULT '0',
  `gateway` int(1) NOT NULL DEFAULT '3',
  `validity` int(5) NOT NULL DEFAULT '0',
  `indirect_ref_amt` double NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `name`, `price`, `currency`, `details`, `tax`, `mpay`, `sbonus`, `cdate`, `active`, `level1`, `stage1_up`, `level2`, `stage2_up`, `level3`, `stage3_up`, `level4`, `stage4_up`, `level5`, `stage5_up`, `level6`, `level7`, `level8`, `level9`, `level10`, `level11`, `level12`, `level13`, `level14`, `level15`, `level16`, `level17`, `level18`, `level19`, `level20`, `level21`, `level22`, `level23`, `level24`, `level25`, `level26`, `level27`, `level28`, `level29`, `level30`, `level31`, `level32`, `level33`, `level34`, `level35`, `level36`, `level37`, `level38`, `level39`, `level40`, `level41`, `level42`, `level43`, `level44`, `level45`, `level46`, `level47`, `level48`, `level49`, `level50`, `level51`, `level52`, `level53`, `level54`, `level55`, `level56`, `level57`, `level58`, `level59`, `level60`, `level61`, `level62`, `level63`, `level64`, `level65`, `level66`, `level67`, `level68`, `level69`, `level70`, `level71`, `level72`, `level73`, `level74`, `level75`, `level76`, `level77`, `level78`, `level79`, `level80`, `level81`, `level82`, `level83`, `level84`, `level85`, `level86`, `level87`, `level88`, `level89`, `level90`, `level91`, `level92`, `level93`, `level94`, `level95`, `level96`, `level97`, `level98`, `level99`, `level100`, `stage6_up`, `stage7_up`, `stage8_up`, `stage9_up`, `stage10_up`, `stage11_up`, `stage12_up`, `stage13_up`, `stage14_up`, `stage15_up`, `stage16_up`, `stage17_up`, `stage18_up`, `stage19_up`, `stage20_up`, `stage21_up`, `stage22_up`, `stage23_up`, `stage24_up`, `stage25_up`, `stage26_up`, `stage27_up`, `stage28_up`, `stage29_up`, `stage30_up`, `stage31_up`, `stage32_up`, `stage33_up`, `stage34_up`, `stage35_up`, `stage36_up`, `stage37_up`, `stage38_up`, `stage39_up`, `stage40_up`, `stage41_up`, `stage42_up`, `stage43_up`, `stage44_up`, `stage45_up`, `stage46_up`, `stage47_up`, `stage48_up`, `stage49_up`, `stage50_up`, `stage51_up`, `stage52_up`, `stage53_up`, `stage54_up`, `stage55_up`, `stage56_up`, `stage57_up`, `stage58_up`, `stage59_up`, `stage60_up`, `stage61_up`, `stage62_up`, `stage63_up`, `stage64_up`, `stage65_up`, `stage66_up`, `stage67_up`, `stage68_up`, `stage69_up`, `stage70_up`, `stage71_up`, `stage72_up`, `stage73_up`, `stage74_up`, `stage75_up`, `stage76_up`, `stage77_up`, `stage78_up`, `stage79_up`, `stage80_up`, `stage81_up`, `stage82_up`, `stage83_up`, `stage84_up`, `stage85_up`, `stage86_up`, `stage87_up`, `stage88_up`, `stage89_up`, `stage90_up`, `stage91_up`, `stage92_up`, `stage93_up`, `stage94_up`, `stage95_up`, `stage96_up`, `stage97_up`, `stage98_up`, `stage99_up`, `stage100_up`, `gateway`, `validity`, `indirect_ref_amt`) VALUES
(1, 'Joining Package', 30, 'USD', 'Newly Joining package', 0, 300, 0, '2016-09-15', 0, 30, 50, 30, 261, 30, 783, 30, 2349, 30, 7047, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 365, 1),
(2, 'Marketing And Advertising Page', 50, 'USD', ' Marketing And Advertising Page', 0, 7000, 49, '2016-11-12', 1, 3, 0, 3, 0, 3, 0, 3, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 33, 3),
(3, '100 pacge', 89, 'USD', 'tets pacakage', 89, 900, 90, '2017-01-22', 1, 8, 8, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 0, 0, 0, 0, 0, 0, 0, 36, 37, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 48, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 0, 0, 0, 0, 0, 0, 0, 36, 37, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 48, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 90, 90);

-- --------------------------------------------------------

--
-- Table structure for table `paymentgateway`
--

CREATE TABLE `paymentgateway` (
  `id` int(11) NOT NULL,
  `Name` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `comment` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paymentgateway`
--

INSERT INTO `paymentgateway` (`id`, `Name`, `status`, `comment`, `date`) VALUES
(1, 'PayPal', 1, 0, '0000-00-00'),
(2, 'Cash On Delivery', 1, 0, '0000-00-00'),
(3, 'Payza', 0, 0, '0000-00-00'),
(4, 'SolidTrustPay', 0, 0, '0000-00-00'),
(5, 'Marketer Balance', 0, 0, '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(6) NOT NULL,
  `userid` varchar(50) NOT NULL,
  `payment_amount` double NOT NULL DEFAULT '0',
  `payment_status` int(1) NOT NULL DEFAULT '0',
  `itemid` varchar(25) NOT NULL,
  `createdtime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `paypalpayments`
--

CREATE TABLE `paypalpayments` (
  `id` int(11) NOT NULL,
  `orderid` int(11) NOT NULL,
  `transacid` text NOT NULL,
  `price` double DEFAULT '0',
  `currency` text NOT NULL,
  `date` date NOT NULL,
  `cod` int(1) NOT NULL DEFAULT '0',
  `renew` int(1) NOT NULL DEFAULT '0',
  `renacid` int(9) NOT NULL COMMENT 'Package choosen at renew time, id of package',
  `pckid` double NOT NULL,
  `gateway` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paypalpayments`
--

INSERT INTO `paypalpayments` (`id`, `orderid`, `transacid`, `price`, `currency`, `date`, `cod`, `renew`, `renacid`, `pckid`, `gateway`) VALUES
(1, 4, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(2, 5, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(3, 6, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(4, 7, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(5, 8, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(6, 9, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(7, 10, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(8, 11, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(9, 12, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(10, 13, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(11, 14, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(12, 15, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(13, 16, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(14, 17, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(15, 18, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(16, 19, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(17, 20, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(18, 21, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(19, 22, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(20, 23, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(21, 24, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(22, 25, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(23, 26, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(24, 27, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(25, 28, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(26, 29, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(27, 30, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(28, 31, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(29, 32, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(30, 33, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(31, 34, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(32, 36, 'C.O.D', 50, 'USD', '2017-01-01', 1, 0, 0, 2, 'C.O.D'),
(33, 39, 'C.O.D', 50, 'USD', '2017-01-02', 1, 0, 0, 2, 'C.O.D'),
(34, 40, 'C.O.D', 50, 'USD', '2017-01-02', 1, 0, 0, 2, 'C.O.D'),
(35, 41, 'C.O.D', 50, 'USD', '2017-01-02', 1, 0, 0, 2, 'C.O.D'),
(36, 42, 'C.O.D', 50, 'USD', '2017-01-02', 1, 0, 0, 2, 'C.O.D'),
(37, 43, 'C.O.D', 50, 'USD', '2017-01-02', 1, 0, 0, 2, 'C.O.D'),
(38, 44, 'C.O.D', 50, 'USD', '2017-01-02', 1, 0, 0, 2, 'C.O.D'),
(39, 46, 'C.O.D', 50, 'USD', '2017-01-02', 1, 0, 0, 2, 'C.O.D'),
(40, 48, 'C.O.D', 50, 'USD', '2017-01-03', 1, 0, 0, 2, 'C.O.D'),
(41, 49, 'C.O.D', 50, 'USD', '2017-01-03', 1, 0, 0, 2, 'C.O.D'),
(42, 50, 'C.O.D', 50, 'USD', '2017-01-03', 1, 0, 0, 2, 'C.O.D'),
(43, 51, 'C.O.D', 50, 'USD', '2017-01-03', 1, 0, 0, 2, 'C.O.D'),
(44, 52, 'C.O.D', 50, 'USD', '2017-01-03', 1, 0, 0, 2, 'C.O.D'),
(45, 53, 'C.O.D', 50, 'USD', '2017-01-03', 1, 0, 0, 2, 'C.O.D'),
(46, 54, 'C.O.D', 50, 'USD', '2017-01-03', 1, 0, 0, 2, 'C.O.D'),
(47, 55, 'C.O.D', 50, 'USD', '2017-01-05', 1, 0, 0, 2, 'C.O.D'),
(48, 56, 'C.O.D', 50, 'USD', '2017-01-06', 1, 0, 0, 2, 'C.O.D'),
(49, 57, 'C.O.D', 50, 'USD', '2017-01-07', 1, 0, 0, 2, 'C.O.D'),
(50, 58, 'C.O.D', 50, 'USD', '2017-01-07', 1, 0, 0, 2, 'C.O.D'),
(51, 59, 'C.O.D', 50, 'USD', '2017-01-07', 1, 0, 0, 2, 'C.O.D'),
(52, 60, 'C.O.D', 50, 'USD', '2017-01-08', 1, 0, 0, 2, 'C.O.D'),
(53, 61, 'C.O.D', 50, 'USD', '2017-01-08', 1, 0, 0, 2, 'C.O.D'),
(54, 63, 'C.O.D', 50, 'USD', '2017-01-08', 1, 0, 0, 2, 'C.O.D'),
(55, 64, 'C.O.D', 50, 'USD', '2017-01-08', 1, 0, 0, 2, 'C.O.D'),
(56, 65, 'C.O.D', 50, 'USD', '2017-01-08', 1, 0, 0, 2, 'C.O.D'),
(57, 66, 'C.O.D', 50, 'USD', '2017-01-08', 1, 0, 0, 2, 'C.O.D'),
(58, 67, 'C.O.D', 50, 'USD', '2017-01-08', 1, 0, 0, 2, 'C.O.D'),
(59, 68, 'C.O.D', 50, 'USD', '2017-01-08', 1, 0, 0, 2, 'C.O.D'),
(60, 69, 'C.O.D', 50, 'USD', '2017-01-12', 1, 0, 0, 2, 'C.O.D'),
(61, 70, 'C.O.D', 50, 'USD', '2017-01-12', 1, 0, 0, 2, 'C.O.D'),
(62, 0, 'C.O.D', 0, '', '2017-01-16', 1, 0, 0, 0, 'C.O.D'),
(63, 72, 'C.O.D', 50, 'USD', '2017-01-16', 1, 0, 0, 2, 'C.O.D'),
(64, 73, 'C.O.D', 50, 'USD', '2017-01-16', 1, 0, 0, 2, 'C.O.D');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `email` varchar(100) NOT NULL DEFAULT 'Enter Your E-Mail Address',
  `sno` int(9) NOT NULL,
  `wlink` varchar(100) NOT NULL DEFAULT 'www.yourwebsite.com',
  `invoicedetails` text NOT NULL,
  `coname` text NOT NULL,
  `fblink` text NOT NULL,
  `twitterlink` text NOT NULL,
  `paypalid` text NOT NULL,
  `maintain` int(1) NOT NULL DEFAULT '0',
  `alwdpayment` int(11) NOT NULL DEFAULT '0' COMMENT 'user will get payment via paypal or via payment in bank account.',
  `minmobile` double NOT NULL,
  `maxmobile` double NOT NULL,
  `footer` varchar(50) NOT NULL,
  `header` varchar(50) NOT NULL,
  `payzaid` varchar(128) NOT NULL DEFAULT 'Not Available',
  `solidtrustid` varchar(128) NOT NULL DEFAULT 'Not Available',
  `solidbutton` varchar(128) NOT NULL DEFAULT 'Not Available'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`email`, `sno`, `wlink`, `invoicedetails`, `coname`, `fblink`, `twitterlink`, `paypalid`, `maintain`, `alwdpayment`, `minmobile`, `maxmobile`, `footer`, `header`, `payzaid`, `solidtrustid`, `solidbutton`) VALUES
('sridhar.subit@gmail.com', 0, 'http://localhost/mlmv2/', 'coimbatore, India', 'Roodabatoz ', 'https://www.facebook.com/ROODAB1/', 'https://twitter.com/@roodabatoz', 'admin@arycapital.com.my', 0, 3, 0, 0, 'Powered By - Roodabatoz:)', 'Roodabatoz', 'Payza', 'Solid', 'Button');

-- --------------------------------------------------------

--
-- Table structure for table `transfer_history`
--

CREATE TABLE `transfer_history` (
  `tid` int(11) NOT NULL,
  `transfer_from` varchar(70) NOT NULL,
  `transfer_to` varchar(70) NOT NULL,
  `amt` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transfer_history`
--

INSERT INTO `transfer_history` (`tid`, `transfer_from`, `transfer_to`, `amt`) VALUES
(359, 'Joshuatang', 'joshuatang2', '130'),
(360, 'Joshuatang2', 'joshuatang', '130'),
(361, 'Joshuatang', 'roodab1', '130'),
(362, 'roodab1', 'million', '150'),
(363, 'Leong8835', '', ''),
(364, 'roodabatoz', 'sri', '10'),
(365, 'roodabatoz', 'roodab', '10'),
(366, 'Roodab7', 'Omid', '10'),
(367, 'adminadmin', 'roodab3', '150'),
(368, 'adminadmin', 'roodab', '170'),
(369, 'adminadmin', 'million', '20'),
(370, 'Roodab', 'ROODAbatoz', '170'),
(371, 'adminadmin', 'roodab', '150'),
(372, 'adminadmin', 'joshuatang3', '133'),
(373, 'adminadmin', 'joshuatang3', '133'),
(374, 'adminadmin', 'leong8835', '133'),
(375, 'adminadmin', 'angsl102', '133'),
(376, 'adminadmin', 'joshuatang2', '133'),
(377, 'adminadmin', 'acashafie', '133'),
(378, 'adminadmin', 'Lisanawi', '133'),
(379, 'Joshuatang2', 'Joshuatang ', '153'),
(380, 'Joshuatang3', 'Joshuatang ', '266'),
(381, 'adminadmin', 'joshuatang4', '197'),
(382, 'adminadmin', 'omid', '133'),
(383, 'adminadmin', 'omid1177', '133'),
(384, 'adminadmin', 'joshuatang4', '206'),
(385, 'adminadmin', 'joshuatang2', '399'),
(386, 'adminadmin', 'joshuatang3', '433'),
(387, 'adminadmin', 'leong8835', '100'),
(388, 'adminadmin', 'angsl102', '100'),
(389, 'adminadmin', 'Roga', '133'),
(390, 'adminadmin', 'saidamo', '133'),
(391, 'adminadmin', 'mahboo2017', '133'),
(392, 'adminadmin', 'tehrani', '133'),
(393, 'adminadmin', 'shafie', '133'),
(394, 'adminadmin', 'hadihh', '133'),
(395, 'adminadmin', 'iman', '133'),
(396, 'adminadmin', 'Sophiahui', '133'),
(397, 'adminadmin', 'Leong88351', '133'),
(398, 'adminadmin', 'Leong88352', '133'),
(399, 'adminadmin', 'Junxian', '133'),
(400, 'adminadmin', 'Leong88353', '133'),
(401, 'adminadmin', 'Tony22', '133'),
(402, 'adminadmin', 'Leong88354', '133'),
(403, 'adminadmin', 'Nicole20', '133'),
(404, 'adminadmin', 'Kanlin93', '133'),
(405, 'adminadmin', 'Teressatang', '133'),
(406, 'adminadmin', 'Soongweng', '133'),
(407, 'adminadmin', 'said2017', '133');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `affiliateuser`
--
ALTER TABLE `affiliateuser`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `Id` (`Id`);

--
-- Indexes for table `affiliate_bonus_history`
--
ALTER TABLE `affiliate_bonus_history`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `affliate_stage_bonus`
--
ALTER TABLE `affliate_stage_bonus`
  ADD PRIMARY KEY (`bonus_id`);

--
-- Indexes for table `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`bannerid`);

--
-- Indexes for table `currency`
--
ALTER TABLE `currency`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `currency` ADD FULLTEXT KEY `code` (`code`);

--
-- Indexes for table `emailtext`
--
ALTER TABLE `emailtext`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paymentgateway`
--
ALTER TABLE `paymentgateway`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paypalpayments`
--
ALTER TABLE `paypalpayments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `transfer_history`
--
ALTER TABLE `transfer_history`
  ADD PRIMARY KEY (`tid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `affiliateuser`
--
ALTER TABLE `affiliateuser`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;
--
-- AUTO_INCREMENT for table `affiliate_bonus_history`
--
ALTER TABLE `affiliate_bonus_history`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;
--
-- AUTO_INCREMENT for table `affliate_stage_bonus`
--
ALTER TABLE `affliate_stage_bonus`
  MODIFY `bonus_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;
--
-- AUTO_INCREMENT for table `banners`
--
ALTER TABLE `banners`
  MODIFY `bannerid` double NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `currency`
--
ALTER TABLE `currency`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `emailtext`
--
ALTER TABLE `emailtext`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `paymentgateway`
--
ALTER TABLE `paymentgateway`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `paypalpayments`
--
ALTER TABLE `paypalpayments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;
--
-- AUTO_INCREMENT for table `transfer_history`
--
ALTER TABLE `transfer_history`
  MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=408;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
