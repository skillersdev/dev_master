<nav class="nav-primary hidden-xs">
                <ul class="nav nav-main" data-ride="collapse">
                  <li class="active"> <a href="dashboard.php" class="auto"> <i class="i i-statistics icon"> </i> <span class="font-bold">Dashboard</span> </a> </li>
<li> <a href="downline.php" class="auto"> <i class="i i-dot"></i> <span>Marketer</span> </a> </li>
                  <li> <a href="invoice.php" class="auto"> <i class="i i-dot"></i> <span>Account Info</span> </a> </li>
				  <li> <a href="profile.php" class="auto"><i class="i i-dot"></i> <span>Profile</span></a> </li>
				   <li> <a href="http://roodabatoz.com/products/"class="auto" target="_blank"><i class="i i-dot"></i> <span>Products</span></a> </li>
				   <li> <a href="http://roodabatoz.com/products/my-account/"class="auto" target="_blank"><i class="i i-dot"></i> <span>Seller Dashboard</span></a> </li>
				   <li> <a href="http://www.neracagemilang.com"class="auto" target="_blank"><i class="i i-dot"></i> <span>Pay Bill</span></a> </li>
				  <li> <a href="logout.php"class="auto"><i class="i i-dot"></i> <span>Logout</span></a> </li>
				  
                  
                  
                </ul>
                <div class="line dk hidden-nav-xs"></div>
                
                
              </nav>