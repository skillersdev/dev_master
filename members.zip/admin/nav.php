 <!-- nav -->
              <nav class="nav-primary hidden-xs">
                <ul class="nav nav-main" data-ride="collapse">
                  <li class="active"> <a href="dashboard.php" class="auto"> <i class="i i-statistics icon"> </i> <span class="font-bold">Dashboard</span> </a> 
				  </li>
                  
                  <li > <a href="#" class="auto"> <span class="pull-right text-muted"> <i class="i i-circle-sm-o text"></i> <i class="i i-circle-sm text-active"></i> </span> <i class="i i-lab icon"> </i> <span class="font-bold">Settings</span> </a>
                    <ul class="nav dk">
                       <li > <a href="pacsettings.php" class="auto"> <i class="i i-dot"></i> <span>Packages Settings</span> </a> </li>
					  
                    </ul>
                  </li>
                  
                  <li >
					<a href="users.php" class="auto"><span class="pull-right text-muted"> <i class="i i-circle-sm-o text"></i> <i class="i i-circle-sm text-active"></i> </span> <i class="i i-grid2 icon"> </i> <span class="font-bold">Manage Users</span></li>
					
                  </li>
		 <li> <a href="payrequest.php" class="auto"><i class="i i-statistics icon"> </i> <span class="font-bold">Payment Request</span> </a> </li>
				<li > <a href="paymentscod.php" class="auto"> <i class="i i-statistics icon"> </i><span class="font-bold">COD Orders </span> </a> </li>
                		  
				  
                </ul>
                <div class="line dk hidden-nav-xs"></div>
                
                
              </nav>
              <!-- / nav -->