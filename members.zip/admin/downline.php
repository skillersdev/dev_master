<?php
include_once ("z_db.php");
// Inialize session
session_start();
// Check, if username session is NOT set then this page will jump to login page
if (!isset($_SESSION['username'])) {
        print "
				<script language='javascript'>
					window.location = 'index.php';
				</script>
			";
}


?>
<!DOCTYPE html>
<html lang="en" class="app">
<head>
<meta charset="utf-8" />
<title>Roodabatoz</title>
<meta name="description" content="app, web app, responsive, admin dashboard, admin, flat, flat ui, ui kit, off screen nav" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<link rel="stylesheet" href="css/app.v1.css" type="text/css" />
    
</head>
<body class="">
<section class="vbox">
  <header class="bg-primary header header-md navbar navbar-fixed-top-xs box-shadow">
    <div class="navbar-header aside-md dk"> <a class="btn btn-link visible-xs" data-toggle="class:nav-off-screen" data-target="#nav"> <i class="fa fa-bars"></i> </a> <a href="dashboard.php" class="navbar-brand"><img src="images/logo.png" class="m-r-sm"><?php $query="SELECT header from settings where sno=0"; 
 
 
 $result = mysqli_query($con,$query);

while($row = mysqli_fetch_array($result))
{
	$header="$row[header]";
	print $header;
	}
  ?></a> <a class="btn btn-link visible-xs" data-toggle="dropdown" data-target=".user"> <i class="fa fa-cog"></i> </a> </div>
  
    
    <ul class="nav navbar-nav navbar-right m-n hidden-xs nav-user user">
      
      <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <span class="thumb-sm avatar pull-left"> <img src="images/a0.jpg"> </span> <?php
		  $sql="SELECT fname FROM  affiliateuser WHERE username='".$_SESSION['username']."'";
		  if ($result = mysqli_query($con, $sql)) {

    /* fetch associative array */
    while ($row = mysqli_fetch_row($result)) {
        print $row[0];
    }

}

   
	   
	   ?> <b class="caret"></b> </a>
        <ul class="dropdown-menu animated fadeInRight">
          <span class="arrow top"></span>
        
          <li> <a href="profile.php">Profile</a> </li>
        
          <li class="divider"></li>
          <li> <a href="logout.php" data-toggle="ajaxModal" >Logout</a> </li>
        </ul>
      </li>
    </ul>
  </header>
  <section>
    <section class="hbox stretch">
      <!-- .aside -->
      <aside class="bg-light aside-md hidden-print" id="nav">
        <section class="vbox">
          <section class="w-f scrollable">
            <div class="slim-scroll" data-height="auto" data-disable-fade-out="true" data-distance="0" data-size="10px" data-color="#333333">
              <div class="clearfix wrapper dk nav-user hidden-xs">
                <div class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <span class="thumb avatar pull-left m-r"> <img src="images/a0.jpg"> <i class="on md b-black"></i> </span> <span class="hidden-nav-xs clear"> <span class="block m-t-xs"> <strong class="font-bold text-lt"><?php
		  $sql="SELECT fname,country,pcktaken FROM  affiliateuser WHERE username='".$_SESSION['username']."'";
		  if ($result = mysqli_query($con, $sql)) {

    /* fetch associative array */
    while ($row = mysqli_fetch_row($result)) {
        print $row[0];
		$coun=$row[1];
		$pcktaken=$row[2];
		 $sql2="SELECT name FROM packages WHERE id=$pcktaken";
		 if ($result2 = mysqli_query($con, $sql2)) {
		  while ($row2 = mysqli_fetch_row($result2)) {
		 $pkname=$row2[0];
		 }
		 }
		
    }

}

//customized Code Part 1 Start
//fetching level settings
  $qu="SELECT * FROM  packages where id = $pcktaken"; 
$re = mysqli_query($con,$qu);
while($r = mysqli_fetch_array($re))
{
	$pckid="$r[id]";
	$pckname="$r[name]";
	$pckprice="$r[price]";
	
	$pckcur="$r[currency]";
	$pcksbonus="$r[sbonus]";
	$l1="$r[level1]";
	$l2="$r[level2]";
	$l3="$r[level3]";
	$l4="$r[level4]";
	$l5="$r[level5]";
	$l6="$r[level6]";
	$l7="$r[level7]";
	$l8="$r[level8]";
	$l9="$r[level9]";
	$l10="$r[level10]";
	$l11="$r[level11]";
	$l12="$r[level12]";
	$l13="$r[level13]";
	$l14="$r[level14]";
	$l15="$r[level15]";
	$l16="$r[level16]";
	$l17="$r[level17]";
	$l18="$r[level18]";
	$l19="$r[level19]";
	$l20="$r[level20]"; 
//fetching elevl settings ends
//Customiezed Code Part 1 Ends
}	
	   ?></strong> <b class="caret"></b> </span> <span class="text-muted text-xs block"><?php print "$pkname Member"; ?></span> </span> </a>
                  <ul class="dropdown-menu animated fadeInRight m-t-xs">
                    <span class="arrow top hidden-nav-xs"></span>
                 
                    <li> <a href="profile.php">Profile</a> </li>
                   
                    <li class="divider"></li>
                    <li> <a href="logout.php" data-toggle="ajaxModal" >Logout</a> </li>
                  </ul>
                </div>
              </div>
              <!-- nav -->
			  <!-- nav -->
              <?php require("user_nav.php"); ?>
              <!-- / nav -->
			  
              
              <!-- / nav -->
            </div>
          </section>
          <footer class="footer hidden-xs no-padder text-center-nav-xs"> <a href="logout.php" data-toggle="ajaxModal" class="btn btn-icon icon-muted btn-inactive pull-right m-l-xs m-r-xs hidden-nav-xs"> <i class="i i-logout"></i> </a> <a href="#nav" data-toggle="class:nav-xs" class="btn btn-icon icon-muted btn-inactive m-l-xs m-r-xs"> <i class="i i-circleleft text"></i> <i class="i i-circleright text-active"></i> </a> </footer>
        </section>
      </aside>
      <!-- /.aside -->
      <section id="content">
        <section class="vbox">
          <header class="header bg-white b-b b-light">
            <p><strong>Downline | </strong>Red = Unverified  AND Green = Verified</p>
          </header>
          <section class="scrollable wrapper">
            <div class="row">
              
              <div class="col-sm-12 portlet">
                <section class="panel panel-success portlet-item">
                  <header class="panel-heading"> Your Referral List </header>
                  <ul class="list-group alt">
				  <div class="col-lg-3">
                <section class="panel panel-default">
                  <div class="panel-body"><h4>My Marketers </h4>
				  
									  
				  </div>
				  <!-- Started Fetching Downline Of User-->
					<?php 

$query121="SELECT * FROM  settings"; 
$result121 = mysqli_query($con,$query121);
$i=0;
while($row121 = mysqli_fetch_array($result121))
{
	$wlink="$row121[wlink]";
}
$pathu="/members/signup.php?aff=";	  


$totalref=0;
$totalrefear=0;
$query="SELECT fname,email,doj,active,username,pcktaken FROM  affiliateuser where referedby = '".$_SESSION['username']."'"; 
  $result = mysqli_query($con,$query);
while($row = mysqli_fetch_array($result))
{
 $ac="$row[active]";
 $countusername="$row[username]";
	$pcktook="$row[pcktaken]";
	$qu="SELECT level1 FROM  packages where id = $pcktook"; 
$re = mysqli_query($con,$qu);
while($r = mysqli_fetch_array($re))
{
	$ll1="$r[0]";
}
if ($ac==1)
{
$status="success";
$totalrefear=$totalrefear+$ll1;
}
else
{
$status="danger";
}

  /*
		<small class='text-muted'>E-Mail : $row[email]</small>
						 <br><small class='text-muted'>Registration Date : $row[doj] </small><br></small>
						 
	*/
	
		

  echo "<li class='list-group-item'>
                      <div class='media'>
                        <div class='pull-right text-$status m-t-sm'> <i class='fa fa-circle'></i> </div>
                        <div class='media-body'>
                          <div><a href='#'>$row[fname]</a></div>
							<br>
							<a href='".$wlink.$pathu.$row['username']."' target='_blank'><small class='text-muted'>Referral Link</small></a><br>
						 
						 </div>
                      </div>
                    </li> ";
  
  
  }

 
print "</br> <P><b>&nbsp;&nbsp;&nbsp; Total Earnings - </b>$pckcur $totalrefear</p>";
?>

				  
                </section>
              </div>
			  
			  
		
			 
<!-- End Fetching Downline Of User-->
                    
				   
				   
				   
                  </ul>
                </section>
                
              </div>
            </div>
          </section>
        </section>
        <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a> </section>
    </section>
  </section>
</section>
<!-- Bootstrap -->
<!-- App -->
<script src="js/app.v1.js"></script>
<script src="js/jquery.ui.touch-punch.min.js"></script>
<script src="js/jquery-ui-1.10.3.custom.min.js"></script>
<script src="js/app.plugin.js"></script>
</body>
</html>