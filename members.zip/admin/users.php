<?php
include_once ("z_db.php");
// Inialize session
session_start();
// Check, if username session is NOT set then this page will jump to login page
if (!isset($_SESSION['adminidusername'])) {
        print "
				<script language='javascript'>
					window.location = 'index.php';
				</script>
			";
}

?>
<!DOCTYPE html>
<html lang="en" class="app">
<head>
<meta charset="utf-8" />
<title>Roodabatoz</title>
<meta name="description" content="app, web app, responsive, admin dashboard, admin, flat, flat ui, ui kit, off screen nav" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<link rel="stylesheet" href="css/app.v1.css" type="text/css" />
<!--[if lt IE 9]> <script src="js/ie/html5shiv.js"></script> <script src="js/ie/respond.min.js"></script> <script src="js/ie/excanvas.js"></script> <![endif]-->

 
</head>
<body class="">
<section class="vbox">
  <header class="bg-white header header-md navbar navbar-fixed-top-xs box-shadow">
    <div class="navbar-header aside-md dk"> <a class="btn btn-link visible-xs" data-toggle="class:nav-off-screen" data-target="#nav"> <i class="fa fa-bars"></i> </a> <a href="dashboard.php" class="navbar-brand"><img src="images/logo.png" class="m-r-sm">Roodabatoz</a> <a class="btn btn-link visible-xs" data-toggle="dropdown" data-target=".user"> <i class="fa fa-cog"></i> </a> </div>
  
    
    <ul class="nav navbar-nav navbar-right m-n hidden-xs nav-user user">
      
      <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <span class="thumb-sm avatar pull-left"> <img src="images/a0.jpg"> </span> <?php
		  $sql="SELECT fname FROM  affiliateuser WHERE username='".$_SESSION['adminidusername']."'";
		  if ($result = mysqli_query($con, $sql)) {

    /* fetch associative array */
    while ($row = mysqli_fetch_row($result)) {
        print $row[0];
    }

}

   
	   
	   ?> <b class="caret"></b> </a>
       <ul class="dropdown-menu animated fadeInRight">
          <span class="arrow top"></span>
          <li> <a href="profile.php">Profile</a> </li>
          <li class="divider"></li>
          <li> <a href="logout.php" data-toggle="ajaxModal" >Logout</a> </li>
        </ul>
      </li>
    </ul>
  </header>
  <section>
    <section class="hbox stretch">
      <!-- .aside -->
      <aside class="bg-black aside-md hidden-print" id="nav">
        <section class="vbox">
          <section class="w-f scrollable">
            <div class="slim-scroll" data-height="auto" data-disable-fade-out="true" data-distance="0" data-size="10px" data-color="#333333">
              <div class="clearfix wrapper dk nav-user hidden-xs">
                <div class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <span class="thumb avatar pull-left m-r"> <img src="images/a0.jpg"> <i class="on md b-black"></i> </span> <span class="hidden-nav-xs clear"> <span class="block m-t-xs"> <strong class="font-bold text-lt"><?php
		  $sql="SELECT fname FROM  affiliateuser WHERE username='".$_SESSION['adminidusername']."'";
		  if ($result = mysqli_query($con, $sql)) {

    /* fetch associative array */
    while ($row = mysqli_fetch_row($result)) {
        print $row[0];
    }

}

   
	   
	   ?></strong> <b class="caret"></b> </span> </span> </a>
                  <ul class="dropdown-menu animated fadeInRight m-t-xs">
                    <span class="arrow top hidden-nav-xs"></span>
                    <li> <a href="profile.php">Profile</a> </li>
                    <li class="divider"></li>
                    <li> <a href="logout.php" data-toggle="ajaxModal" >Logout</a> </li>
                  </ul>
                </div>
              </div>
              <!-- nav -->
              <?php require("nav.php"); ?>
              <!-- / nav -->
            </div>
          </section>
          <footer class="footer hidden-xs no-padder text-center-nav-xs"> <a href="logout.php" data-toggle="ajaxModal" class="btn btn-icon icon-muted btn-inactive pull-right m-l-xs m-r-xs hidden-nav-xs"> <i class="i i-logout"></i> </a> <a href="#nav" data-toggle="class:nav-xs" class="btn btn-icon icon-muted btn-inactive m-l-xs m-r-xs"> <i class="i i-circleleft text"></i> <i class="i i-circleright text-active"></i> </a> </footer>
        </section>
      </aside>
      <!-- /.aside -->
      <section id="content">
        <section class="vbox">
          <header class="header bg-white b-b b-light">
            <p><strong>Important Instructions </strong> <b>1.</b> If you find unknown status of user, then kindly edit the user profile and update the status.</p>
          </header>
          <section class="scrollable wrapper">
            <div class="row">
              
              <div class="col-sm-12 portlet">
                <section class="panel panel-success portlet-item">
                  <header class="panel-heading"> Manage Users </header>
                  <section class="panel panel-default">
                  
                  <div class="panel-body">
                    <div class="tab-content">
                      <div class="tab-pane active" id="home">
					  
					  
					  <div class="panel-body">
                    
					  
<div class="table-responsive">

		
                <table id="example" class="table table-striped table-bordered" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                     
                      <th>User id/Order id</th>
					  <th>Username</th>
                      <th> Full Name</th>
                      <th>Country</th>
					  <th>Sponsor</th>
					  <th>Earnings</th>
					  <th>Tot Marketer</th>
					  <th>Package Taken</th>
					  <th>Reg. Date</th>
					  <th>Status</th>
					  <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
				  <?php $query="SELECT * FROM  affiliateuser  ORDER BY id DESC"; 
 
 
 $result = mysqli_query($con,$query);
$i=1;
while($row = mysqli_fetch_array($result))
{
	
	$id="$row[Id]";
	$username="$row[username]";
	$fname="$row[fname]";
	$email="$row[email]";
	$mobile="$row[mobile]";
	$active="$row[active]";
	$doj="$row[doj]";
	$country="$row[country]";
	$ear="$row[tamount]";
	$ref="$row[referedby]";
	$pck="$row[pcktaken]";
	$lprofile="$row[launch]";
	
	$s1=mysqli_query($con,"SELECT  COUNT(*) as STAGE1TOTUSER FROM affiliateuser as a,affiliate_bonus_history as b
	 WHERE (b.stage1_ref = '$username' || b.stage2_ref = '$username' || b.stage3_ref = '$username' || b.stage4_ref = '$username' || b.stage5_ref = '$username' || b.stage6_ref = '$username' || b.stage7_ref = '$username' || b.stage8_ref = '$username' || b.stage9_ref = '$username' || b.stage10_ref = '$username' || b.stage11_ref = '$username' || b.stage12_ref = '$username' || b.stage13_ref = '$username' || b.stage14_ref = '$username' || b.stage15_ref = '$username' || b.stage16_ref = '$username' || b.stage17_ref = '$username' || b.stage18_ref = '$username' || b.stage19_ref = '$username' || b.stage20_ref = '$username' || b.stage21_ref = '$username' || b.stage22_ref = '$username' || b.stage23_ref = '$username' || b.stage24_ref = '$username' || b.stage25_ref = '$username' || b.stage26_ref = '$username' || b.stage27_ref = '$username' || b.stage28_ref = '$username' || b.stage29_ref = '$username' || b.stage30_ref = '$username' || b.stage31_ref = '$username' || b.stage32_ref = '$username' || b.stage33_ref = '$username' || b.stage34_ref = '$username' || b.stage35_ref = '$username' || b.stage36_ref = '$username' || b.stage37_ref = '$username' || b.stage38_ref = '$username' || b.stage39_ref = '$username' || b.stage40_ref = '$username' || b.stage41_ref = '$username' || b.stage42_ref = '$username' || b.stage43_ref = '$username' || b.stage44_ref = '$username' || b.stage45_ref = '$username' || b.stage46_ref = '$username' || b.stage47_ref = '$username' || b.stage48_ref = '$username' || b.stage49_ref = '$username' || b.stage50_ref = '$username' || b.stage51_ref = '$username' || b.stage52_ref = '$username' || b.stage53_ref = '$username' || b.stage54_ref = '$username' || b.stage55_ref = '$username' || b.stage56_ref = '$username' || b.stage57_ref = '$username' || b.stage58_ref = '$username' || b.stage59_ref = '$username' || b.stage60_ref = '$username' || b.stage61_ref = '$username' || b.stage62_ref = '$username' || b.stage63_ref = '$username' || b.stage64_ref = '$username' || b.stage65_ref = '$username' || b.stage66_ref = '$username' || b.stage67_ref = '$username' || b.stage68_ref = '$username' || b.stage69_ref = '$username' || b.stage70_ref = '$username' || b.stage71_ref = '$username' || b.stage72_ref = '$username' || b.stage73_ref = '$username' || b.stage74_ref = '$username' || b.stage75_ref = '$username' || b.stage76_ref = '$username' || b.stage77_ref = '$username' || b.stage78_ref = '$username' || b.stage79_ref = '$username' || b.stage80_ref = '$username' || b.stage81_ref = '$username' || b.stage82_ref = '$username' || b.stage83_ref = '$username' || b.stage84_ref = '$username' || b.stage85_ref = '$username' || b.stage86_ref = '$username' || b.stage87_ref = '$username' || b.stage88_ref = '$username' || b.stage89_ref = '$username' || b.stage90_ref = '$username' || b.stage91_ref = '$username' || b.stage92_ref = '$username' || b.stage93_ref = '$username' || b.stage94_ref = '$username' || b.stage95_ref = '$username' || b.stage96_ref = '$username' || b.stage97_ref = '$username' || b.stage98_ref = '$username' || b.stage99_ref = '$username' || b.stage100_ref = '$username') AND (a.username = b.user_id )");
	$stage1_list=$s1->fetch_array(MYSQLI_ASSOC);
	$stage1_count=$stage1_list['STAGE1TOTUSER'];
	
	
	
	if($active==1)
	{
	$status="Active/Paid";
	}
	else if($active==0)
	{
	$status="UnActive/Unpaid";
	}
	else
	{
	$status="Unknown";
	}
	
  print "<tr>
				  
				  <td>
				  $i
				  </td>
				  <td>
				  $username
				  </td>
				  <td>
				  $fname
				  </td>
				  <td>
				  $country
				  </td>
				  
				  <td>
				  $ref
				  </td>
				  
				  <td>
				  $ear
				  </td>
				  <td>
				  $stage1_count
				  </td>
				  
				  <td>
				  $pck
				  </td>
				  <td>
				  $doj
				  </td>
				  <td>
				  
				  $status
				  </td>
				  <td>
				 
				  <a href='updateuser.php?username=$username'>Edit</a> <br/>
				  <a href='deleteuser.php?username=$username' Onclick='return ConfirmDelete()'>Delete</a> <br/>
				  ";
				  
				  	  
	
	
				  
		print"		  </p> 
				  </td>
				  
				  </tr>";
  $i++;
  }
  ?>
				  
                  </tbody>
                </table>
              </div>
        
          <script>
			function ConfirmDelete()
			{
			  var x = confirm("Are you sure you want to delete?");
			  if (x)
				  return true;
			  else
				return false;
			}
		  </script>
                    
                    
                  </div>
					  
					  </div>


                      
                    </div>
                  </div>
                </section>
                </section>
                
              </div>
            </div>
          </section>
        </section>
        <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a> </section>
    </section>
  </section>
</section>
<!-- Bootstrap -->
<!-- App -->

<script src="js/app.v1.js"></script>
<script src="js/jquery.ui.touch-punch.min.js"></script>
<script src="js/jquery-ui-1.10.3.custom.min.js"></script>
<script src="js/app.plugin.js"></script>

<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" />
<script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>

<script>
	$(document).ready(function() {
		$('#example').DataTable();
	} );
</script>


</body>
</html>